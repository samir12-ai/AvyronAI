export const AUDIENCE_ENGINE_VERSION = 3;

export const AUDIENCE_THRESHOLDS = {
  MIN_COMMENTS_FOR_ANALYSIS: 50,
  MIN_POSTS_FOR_ANALYSIS: 20,
  MIN_COMPETITORS_FOR_ANALYSIS: 3,
  MIN_SIGNAL_MATCHES_FOR_AI: 5,
  MAX_COMMENTS_TO_ANALYZE: 500,
  MAX_POSTS_TO_ANALYZE: 150,
  DEFENSIVE_MODE_SIGNAL_THRESHOLD: 10,
} as const;

export const BRIDGE_SUPPRESS_THRESHOLD = 0.55;

export const COMMENT_QUALITY_WEIGHTS = {
  HIGH: 1.0,
  MEDIUM: 0.6,
  LOW: 0.25,
} as const;

export const LOW_SIGNAL_COMMENT_PHRASES = [
  "thank you", "thanks!", "great", "amazing", "awesome", "love this",
  "love it", "so good", "nice", "wow", "🔥", "👏", "🙏", "💯",
  "❤️", "woot", "yes!", "cool", "haha", "lol", "go ", "!!", "so excited",
  "congratulations", "congrats", "well done", "good job", "keep going",
] as const;

export const SYNTHETIC_FILTERS = [
  "synthetic",
  "engagement signal",
  "reported comments",
  "[synthetic-",
  "synthetic-positive",
  "synthetic-negative",
  "synthetic-neutral",
  "test comment placeholder",
  "auto-generated engagement",
  "crawler artifact",
  "scrape-marker",
  "bot-generated",
] as const;

export type MarketScope = "universal" | "fitness" | "health" | "marketing" | "ecommerce" | "education" | "finance" | "tech" | "beauty" | "food";

export interface PatternCluster {
  canonical: string;
  patterns: string[];
  marketScope?: MarketScope[];
}

export const OBJECTION_CONTEXT_RULES: Record<string, { requireKeywords: string[]; fallbackCanonical: string }> = {
  "physical limitations": {
    requireKeywords: [
      "injury", "pain", "rehab", "recovery", "medical", "disability", "physical therapy",
      "back pain", "knee pain", "surgery", "chronic", "mobility", "wheelchair", "postpartum",
      "pregnant", "elderly", "senior", "arthritis", "fibromyalgia", "inflammation",
      "إصابة", "ألم", "علاج", "عملية",
    ],
    fallbackCanonical: "complexity / too hard",
  },
};

export const MIN_EVIDENCE_PER_SIGNAL = 3;

export const PAIN_CLUSTERS: PatternCluster[] = [
  { canonical: "frustration with lack of results", patterns: [
    "no results", "nothing works", "not working", "didn't work", "still the same", "nothing changed",
    "waste of time", "waste of money", "no progress", "plateau", "stuck", "not seeing results",
    "ما في نتيجة", "ما في فايدة", "ما نفع", "مش شغال", "ما اشتغل", "بدون نتيجة",
    "doesn't do anything", "complete waste", "zero results", "not improving", "going nowhere",
    "no difference", "same as before", "useless", "pointless", "still struggling",
  ]},
  { canonical: "confusion and overwhelm", patterns: [
    "confused", "don't understand", "overwhelming", "too much info", "information overload",
    "makes no sense", "complicated", "contradicting", "don't know where to start", "conflicting advice",
    "محتار", "مش فاهم", "معقد", "كتير معلومات", "شو يعني", "ما بعرف شو أعمل",
    "lost", "clueless", "what does this mean", "don't get it", "so confusing",
    "hard to understand", "over my head", "too complex", "brain fog", "mind blown",
  ]},
  { canonical: "time pressure", patterns: [
    "no time", "don't have time", "takes too long", "too busy", "how long does it take",
    "quick results", "fast results", "short on time", "busy schedule", "time consuming",
    "ما عندي وقت", "مشغول", "بدي شي سريع", "قديش بياخد وقت",
    "can't commit the time", "time is limited", "need faster", "not enough hours",
    "juggling too much", "between work and", "full time job", "kids and work",
  ]},
  { canonical: "cost and affordability concerns", patterns: [
    "expensive", "too much money", "can't afford", "not worth it", "overpriced",
    "cheaper alternative", "budget", "free option", "cost too much", "pricing",
    "غالي", "ما معي مصاري", "مش قادر أدفع", "كم سعره", "في أرخص",
    "is it worth it", "money tight", "on a budget", "broke", "save money",
    "subscription cost", "hidden fees", "pay monthly", "cancel subscription", "refund",
  ]},
  { canonical: "trust and credibility doubts", patterns: [
    "scam", "fake", "is this legit", "too good to be true", "don't trust",
    "honest review", "real results", "proof", "before and after", "can you prove",
    "نصب", "كذب", "حقيقي", "مضمون", "مين جرب",
    "is this real", "sketchy", "sounds fishy", "not buying it", "prove it works",
    "show me proof", "anyone actually tried", "legit or scam", "unbiased review", "verified",
  ]},
  { canonical: "fear of failure", patterns: [
    "afraid to try", "what if it doesn't work", "scared", "fear of", "worried",
    "anxious about", "might fail", "risk", "lose money", "regret",
    "خايف", "شو لو ما نفع", "محتار أجرب", "خسارة",
    "nervous about starting", "don't want to fail", "scared to invest", "risky",
    "what if i waste", "too afraid", "fear of commitment", "hesitant", "doubt myself",
  ]},
  { canonical: "body image struggles", marketScope: ["fitness", "health", "beauty"], patterns: [
    "belly fat", "stomach fat", "love handles", "waist won't shrink", "body fat",
    "overweight", "flabby", "skinny fat", "loose skin", "stubborn fat",
    "كرش", "وزن زايد", "دهون", "جسمي مش حلو",
    "muffin top", "double chin", "cellulite", "stretch marks", "bloated",
    "body shape", "hate my body", "fat arms", "thick thighs", "beer belly",
  ]},
  { canonical: "motivation and consistency issues", patterns: [
    "can't stay consistent", "lose motivation", "keep quitting", "hard to maintain",
    "discipline", "give up", "fall off", "lack of motivation", "no willpower", "lazy",
    "ما بقدر كمل", "بوقف بالنص", "ما عندي حافز",
    "inconsistent", "on and off", "yo-yo", "start and stop", "procrastinate",
    "keep falling off", "can't stick with it", "always quit", "unmotivated", "burned out",
  ]},
  { canonical: "injury or health limitations", marketScope: ["fitness", "health"], patterns: [
    "injury", "bad knee", "back pain", "joint pain", "can't exercise", "health condition",
    "limited mobility", "chronic pain", "recovery", "doctor said",
    "إصابة", "ألم", "ما بقدر أتمرن", "مشاكل صحية",
    "herniated disc", "torn ligament", "surgery recovery", "physical therapy",
    "medical condition", "disabled", "arthritis", "fibromyalgia", "inflammation",
  ]},
  { canonical: "diet and nutrition confusion", marketScope: ["fitness", "health", "food"], patterns: [
    "what to eat", "diet plan", "meal prep", "macros", "calories", "nutrition",
    "carbs", "protein intake", "keto", "fasting", "diet confusion", "eating right",
    "شو آكل", "حمية", "دايت", "سعرات", "أكل صحي",
    "cheat meal", "binge eating", "emotional eating", "food cravings", "counting calories",
    "meal plan", "intermittent fasting", "clean eating", "whole foods", "organic",
  ]},
  { canonical: "social comparison and pressure", patterns: [
    "everyone else is", "falling behind", "comparing myself", "social media pressure",
    "influencer", "unrealistic standards", "photoshopped", "filter",
    "الكل قدامي", "ليش هو قدر وأنا لأ",
    "feel left out", "imposter syndrome", "not good enough", "behind my peers",
    "everyone is ahead", "comparison trap", "fake lifestyle", "highlight reel",
  ]},
  { canonical: "lack of knowledge or guidance", patterns: [
    "don't know how", "need a coach", "need guidance", "where do i learn",
    "no one to ask", "self taught", "trial and error",
    "ما بعرف كيف", "بدي حدا يساعدني", "محتاج مدرب",
    "need mentor", "need help", "guide me", "teach me", "show me how",
    "step by step", "what am i doing wrong", "correct my form", "am i doing this right",
  ]},
];

export const DESIRE_CLUSTERS: PatternCluster[] = [
  { canonical: "lose weight / fat loss", marketScope: ["fitness", "health"], patterns: [
    "lose weight", "fat loss", "burn fat", "shed pounds", "slim down", "get lean",
    "drop weight", "weight loss", "lose belly fat", "cut fat",
    "بدي أنحف", "خس", "حرق دهون", "نزل وزن",
    "shred", "tone down", "lean out", "drop body fat", "lose inches",
    "flatten stomach", "reduce waist", "body recomp", "cut weight", "trim down",
  ]},
  { canonical: "build muscle / get stronger", marketScope: ["fitness", "health"], patterns: [
    "build muscle", "gain muscle", "get stronger", "bulk up", "muscle growth",
    "muscle gain", "tone up", "get toned", "get fit", "body building",
    "بدي عضلات", "أقوى", "تضخيم",
    "pack on muscle", "hypertrophy", "strength training", "powerlifting", "lift heavier",
    "add size", "muscular", "gains", "mass building", "ripped",
  ]},
  { canonical: "look better / aesthetic goals", marketScope: ["fitness", "health", "beauty"], patterns: [
    "look good", "look better", "look athletic", "physique", "aesthetic",
    "beach body", "six pack", "abs", "attractive", "transform my body",
    "شكلي", "حلو", "رشيق", "جسم حلو",
    "v-taper", "symmetry", "lean physique", "shredded", "model body",
    "summer body", "wedding body", "photo ready", "stage ready", "competition prep",
  ]},
  { canonical: "increase confidence", patterns: [
    "more confident", "self confidence", "feel confident", "believe in myself",
    "self esteem", "feel good about myself", "proud of", "confidence boost",
    "ثقة بالنفس", "بدي أحس أحسن", "فخور",
    "self-worth", "empowered", "own it", "stand tall", "walk with confidence",
    "love myself", "self-love", "body confidence", "feel powerful", "inner strength",
  ]},
  { canonical: "improve health", marketScope: ["fitness", "health"], patterns: [
    "healthier", "better health", "improve health", "healthy lifestyle", "longevity",
    "feel better", "more energy", "sleep better", "reduce stress",
    "صحة", "أحسن", "طاقة", "نوم أحسن",
    "lower blood pressure", "reduce cholesterol", "heart health", "immune system",
    "mental health", "wellness", "hormone balance", "gut health", "anti-aging",
  ]},
  { canonical: "achieve transformation", patterns: [
    "transformation", "before and after", "life change", "new me", "complete change",
    "glow up", "total body transformation", "makeover",
    "تحول", "تغيير", "شخص جديد",
    "reinvent myself", "start fresh", "turn my life around", "new chapter",
    "180 degree change", "become a new person", "total overhaul", "rebirth",
  ]},
  { canonical: "learn skills / knowledge", patterns: [
    "learn how to", "teach me", "want to know", "understand", "educate myself",
    "master", "get better at", "improve my", "skill up",
    "بدي أتعلم", "علمني", "كيف أعمل", "فهمني",
    "upskill", "level up", "become expert", "knowledge", "training",
    "course", "certification", "workshop", "seminar", "bootcamp",
  ]},
  { canonical: "save time / efficiency", patterns: [
    "save time", "efficient", "quick workout", "less time", "shortcut",
    "faster results", "time saving", "optimize", "streamline",
    "وقت أقل", "أسرع", "بسرعة",
    "30 minute workout", "busy schedule friendly", "at home workout",
    "no gym needed", "minimal equipment", "time efficient", "productive",
  ]},
  { canonical: "financial improvement", marketScope: ["marketing", "ecommerce", "finance", "tech"], patterns: [
    "make money", "earn more", "side hustle", "passive income", "financial freedom",
    "grow business", "revenue", "profit", "monetize",
    "مصاري", "دخل", "ربح", "عمل",
    "scale business", "client acquisition", "increase sales", "roi", "investment return",
    "6 figures", "quit my job", "full time income", "freelance", "entrepreneur",
  ]},
  { canonical: "social recognition / status", patterns: [
    "impress", "respect", "admired", "envied", "status", "stand out",
    "noticed", "popular", "influence", "reputation",
    "تقدير", "احترام", "مشهور",
    "viral", "followers", "fame", "authority", "thought leader",
    "industry expert", "recognized", "spotlight", "credibility", "clout",
  ]},
  { canonical: "community and belonging", patterns: [
    "community", "group", "tribe", "support system", "accountability partner",
    "like-minded", "team", "network", "connection",
    "مجتمع", "جماعة", "أصحاب",
    "squad goals", "training partner", "gym buddy", "support group", "family",
    "belong", "fit in", "acceptance", "brotherhood", "sisterhood",
  ]},
];

export const OBJECTION_CLUSTERS: PatternCluster[] = [
  { canonical: "too expensive", patterns: [
    "too expensive", "can't afford", "not worth the price", "overpriced",
    "cheaper option", "free alternative", "budget constraint", "costs too much", "waste of money",
    "غالي", "ما معي", "مش قادر أدفع", "في أرخص",
    "rip off", "daylight robbery", "not in my budget", "save up", "installment plan",
    "hidden costs", "recurring charges", "cancel anytime", "money back guarantee",
  ]},
  { canonical: "no time", patterns: [
    "no time", "too busy", "don't have time", "time consuming", "takes too long",
    "busy schedule", "can't commit", "not enough hours",
    "ما عندي وقت", "مشغول كتير",
    "between work and family", "full plate", "overwhelmed with tasks", "packed schedule",
    "barely have time to eat", "working two jobs", "single parent", "night shift",
  ]},
  { canonical: "tried before and failed", patterns: [
    "tried before", "didn't work last time", "already tried", "nothing works for me",
    "failed before", "gave up", "been there", "tried everything",
    "جربت قبل", "ما نفع معي", "كل شي جربته",
    "been burned before", "fool me once", "lost count how many times", "same old story",
    "wasted money before", "nothing sticks", "always bounce back", "rebound",
  ]},
  { canonical: "skepticism / doesn't believe it works", patterns: [
    "doesn't work", "too good to be true", "skeptical", "doubt", "hard to believe",
    "sounds fake", "not convinced", "prove it",
    "مش مصدق", "كذب", "مستحيل",
    "snake oil", "marketing gimmick", "just hype", "all talk", "show me data",
    "where's the proof", "scientific evidence", "peer reviewed", "clinical study",
  ]},
  { canonical: "fear of commitment", patterns: [
    "long term", "commitment", "lock in", "contract", "cancel",
    "what if i change my mind", "not ready", "big decision",
    "التزام", "عقد", "مش جاهز",
    "trial period", "test it first", "money back", "no strings attached",
    "flexibility", "pause option", "month to month", "no long term commitment",
  ]},
  { canonical: "complexity / too hard", patterns: [
    "too complicated", "too hard", "too difficult", "overwhelming", "complex",
    "not for me", "can't do it", "not smart enough", "confusing",
    "صعب", "معقد", "مش إلي",
    "steep learning curve", "too technical", "need instructions", "dumbed down version",
    "simplified", "easy to follow", "beginner friendly", "plug and play",
  ]},
  { canonical: "lack of support", patterns: [
    "no support", "on my own", "no help", "nobody to ask", "no community",
    "alone", "no guidance", "unsupported",
    "لحالي", "ما حدا ساعدني",
    "customer service", "response time", "live chat", "phone support",
    "FAQ only", "no human", "automated response", "ticket system",
  ]},
  { canonical: "physical limitations", marketScope: ["fitness", "health"], patterns: [
    "injury", "health issue", "age", "too old", "condition", "disability",
    "can't physically", "limited", "pain",
    "إصابة", "كبير بالعمر", "مش قادر",
    "chronic condition", "mobility issues", "wheelchair", "post surgery",
    "pregnant", "postpartum", "elderly", "senior", "modified exercises",
  ]},
  { canonical: "information overload / analysis paralysis", patterns: [
    "too many options", "don't know which", "analysis paralysis", "overwhelmed by choices",
    "which one is best", "so many programs", "decision fatigue",
    "كتير خيارات", "مش عارف شو أختار",
    "paradox of choice", "just tell me what to do", "simple plan", "one program",
    "stop overthinking", "just pick one", "all look the same", "what's different",
  ]},
];

export const TRANSFORMATION_PATTERNS: PatternCluster[] = [
  { canonical: "overweight → lean body", patterns: [
    "lost weight", "fat to fit", "overweight to", "went from", "pounds lost",
    "before and after weight", "used to be fat",
    "نحفت", "كنت سمين", "خسيت",
    "dropped 20 pounds", "down 3 sizes", "fit in old clothes", "no more plus size",
    "went from XL to M", "lost the gut", "shrunk my waist",
  ]},
  { canonical: "weak → strong", patterns: [
    "got stronger", "weak to strong", "couldn't lift", "now i can",
    "strength gain", "progress", "personal record", "pr",
    "صرت أقوى", "كنت ضعيف",
    "deadlift pr", "bench press went up", "squat more", "first pull up",
    "double bodyweight", "strength doubled", "no longer weak",
  ]},
  { canonical: "unconfident → confident", patterns: [
    "gained confidence", "feel confident now", "used to hide", "now i show",
    "self esteem improved", "believe in myself now",
    "صرت واثق", "كنت خجول",
    "no longer shy", "own it now", "walk with pride", "love my reflection",
    "take up space", "speak up now", "not ashamed anymore",
  ]},
  { canonical: "confused → knowledgeable", patterns: [
    "now i understand", "finally get it", "everything clicked", "makes sense now",
    "learned so much", "knowledge changed",
    "فهمت", "صار واضح",
    "light bulb moment", "game changer", "wish i knew sooner", "eye opener",
    "completely changed my perspective", "now i see", "the penny dropped",
  ]},
  { canonical: "unhealthy → healthy lifestyle", patterns: [
    "changed my life", "healthy now", "feel amazing", "energy levels up",
    "sleeping better", "no more medication",
    "صحتي تحسنت", "بقيت أحسن",
    "off my meds", "blood work improved", "doctor is impressed",
    "no more pain", "reversed my condition", "clean bill of health",
  ]},
  { canonical: "beginner → experienced", patterns: [
    "started as beginner", "been doing this for", "years of experience",
    "journey", "when i started", "come a long way",
    "كنت مبتدئ", "صرت خبير",
    "newbie to pro", "zero to hero", "from scratch", "self taught to expert",
    "certified now", "teach others now", "mentor beginners",
  ]},
  { canonical: "stuck → progressing", patterns: [
    "broke through plateau", "finally seeing results", "making progress",
    "moving forward", "unstuck", "breakthrough",
    "بلشت أتقدم", "كسرت الحاجز",
    "overcame the plateau", "back on track", "momentum building",
    "seeing changes", "numbers moving", "consistent progress",
  ]},
  { canonical: "isolated → connected", patterns: [
    "found my community", "not alone anymore", "found my tribe",
    "accountability partner", "training buddies",
    "لقيت ناس متلي", "مش لحالي",
    "support system", "made friends", "belong somewhere", "team environment",
  ]},
  { canonical: "broke → financially free", patterns: [
    "quit my job", "financial freedom", "making money now", "first sale",
    "replaced my income", "6 figures",
    "صرت أكسب", "تركت شغلي",
    "passive income stream", "business took off", "clients flooding in",
    "paid off debt", "first 10k month", "scaled to",
  ]},
];

export const EMOTIONAL_DRIVER_PATTERNS: PatternCluster[] = [
  { canonical: "shame / embarrassment", patterns: [
    "ashamed", "embarrassed", "embarrassing", "hate my body", "can't look in mirror",
    "hide", "cover up", "disgusted", "humiliated",
    "خجلان", "مستحي", "بكره جسمي",
    "mortified", "cringe", "walk of shame", "laughed at", "mocked",
    "bullied", "ridiculed", "pointed at", "stared at", "judged",
  ]},
  { canonical: "confidence / self-worth", patterns: [
    "confident", "self worth", "feel good", "proud", "empowered",
    "self love", "believe in", "worthy", "self image",
    "واثق", "فخور", "أحسن",
    "self-assured", "own it", "boss energy", "queen energy", "king energy",
    "main character", "glow up", "level up", "power move",
  ]},
  { canonical: "fear / anxiety", patterns: [
    "scared", "afraid", "anxious", "worried", "nervous", "fear of",
    "panic", "terrified", "dread", "overwhelmed",
    "خايف", "قلقان", "مرعوب",
    "sleepless nights", "can't stop thinking", "worst case scenario",
    "anxiety attack", "stomach in knots", "heart racing", "cold sweat",
  ]},
  { canonical: "desire for attractiveness", patterns: [
    "attractive", "hot", "sexy", "good looking", "beauty",
    "handsome", "desirable", "turn heads", "eye catching",
    "حلو", "جذاب", "وسيم",
    "head turner", "stunning", "gorgeous", "jaw dropping",
    "date material", "partner attraction", "look younger", "aging gracefully",
  ]},
  { canonical: "status / social proof", patterns: [
    "impress", "respect", "admire", "jealous", "envy", "status",
    "cool", "popular", "recognized", "influence",
    "مشهور", "محترم", "يحسدوني",
    "flex", "show off", "humble brag", "look at me now",
    "they doubted me", "proved them wrong", "last laugh", "success story",
  ]},
  { canonical: "frustration / anger", patterns: [
    "angry", "furious", "rage", "pissed", "annoyed", "irritated",
    "fed up", "had enough", "sick of", "done with",
    "زعلان", "معصب", "طفشت",
    "over it", "can't take it anymore", "last straw", "breaking point",
    "losing my mind", "steam coming out", "blood boiling",
  ]},
  { canonical: "hope / aspiration", patterns: [
    "dream", "hope", "aspire", "wish", "one day", "goal",
    "vision", "imagine", "someday", "possibility",
    "حلم", "أمل", "إن شاء الله",
    "manifest", "believe", "future self", "best version",
    "make it happen", "it's possible", "never give up", "keep going",
  ]},
  { canonical: "guilt / regret", patterns: [
    "guilty", "regret", "should have", "wish i had", "missed opportunity",
    "too late", "wasted time", "if only", "blame myself",
    "ندمان", "يا ريت", "ضيعت وقت",
    "coulda shoulda", "hindsight", "looking back", "past mistakes",
    "second chance", "start over", "better late than never",
  ]},
  { canonical: "belonging / community", patterns: [
    "community", "together", "belong", "team", "family",
    "support group", "tribe", "accountability", "partner",
    "عائلة", "مجتمع", "سوا",
    "we're in this together", "squad", "crew", "gang",
    "brotherhood", "sisterhood", "like-minded people", "my people",
  ]},
  { canonical: "desperation / urgency", patterns: [
    "desperate", "need this now", "last chance", "running out of time",
    "urgent", "emergency", "can't wait", "immediately",
    "محتاج هلق", "ضروري", "مستعجل",
    "asap", "right now", "today", "before it's too late", "deadline",
    "clock is ticking", "now or never", "do or die",
  ]},
];

export const AWARENESS_PATTERNS = {
  UNAWARE: [
    "what is this", "never heard of", "what does that mean", "i don't know what", "first time seeing",
    "شو هاد", "أول مرة بسمع",
    "what is that", "new to me", "no idea what", "never seen this before",
    "huh", "what are you talking about", "explain this", "eli5",
    "what's that about", "sounds new", "unfamiliar with", "not sure what that is",
  ],
  PROBLEM_AWARE: [
    "i have this problem", "struggling with", "can't figure out", "need help with",
    "dealing with", "suffering from",
    "عندي مشكلة", "مش قادر", "بعاني من",
    "my issue is", "problem is", "challenge is", "difficulty with",
    "can't seem to", "having trouble", "it's hard to", "frustrated by",
    "bothered by", "concerned about", "worried about", "stressed about",
    "how do i fix", "why can't i", "what's wrong with",
  ],
  SOLUTION_AWARE: [
    "looking for a solution", "what's the best way", "options for", "alternatives",
    "compared to", "which one is better", "reviews",
    "شو الحل", "شو الأحسن", "بدائل",
    "best option", "top rated", "recommended", "which should i choose",
    "pros and cons", "comparison", "vs", "versus", "better than",
    "what do you recommend", "anyone tried", "best for beginners",
    "which program", "which app", "which tool", "what's good for",
  ],
  PRODUCT_AWARE: [
    "heard about", "seen your", "your product", "this brand", "recommend",
    "does it work", "thinking about buying",
    "سمعت عن", "منتجكم", "بفكر أشتري",
    "your program", "your course", "your service", "your coaching",
    "tell me more about", "what's included", "features", "pricing",
    "demo", "trial", "sample", "preview", "what makes this different",
  ],
  MOST_AWARE: [
    "ready to buy", "where to order", "sign me up", "take my money",
    "just bought", "already using", "subscriber", "member",
    "بدي أشتري", "وين أسجل", "اشتريت",
    "how do i sign up", "enrollment open", "when does it start",
    "payment link", "checkout", "add to cart", "purchase now",
    "registered", "enrolled", "just joined", "day one", "let's go",
  ],
} as const;

export const MATURITY_KEYWORDS = {
  BEGINNER: [
    "how do i", "what is", "help me", "i don't know", "confused",
    "just starting", "beginner", "new to", "first time", "where do i start",
    "basic", "simple", "easy", "newbie", "getting started",
    "كيف أبدأ", "مبتدئ", "أول مرة", "شو يعني",
    "explain like i'm five", "eli5", "dummy guide", "step by step",
    "complete beginner", "from zero", "starting out", "noob", "rookie",
    "never done this", "brand new", "total newbie", "clueless",
  ],
  DEVELOPING: [
    "i've tried", "compared to", "which is better", "my experience",
    "routine", "protocol", "strategy", "method", "approach",
    "i switched from", "alternative", "recommendation", "what worked for me",
    "جربت", "أفضل", "طريقتي",
    "been doing this for a while", "intermediate", "some experience",
    "tried a few", "next level", "progress so far", "hitting plateau",
    "refining my", "tweaking", "adjusting", "fine tuning", "upgrading",
  ],
  MATURE: [
    "roi", "conversion", "funnel", "optimization", "scaling",
    "metrics", "kpi", "attribution", "retention", "ltv",
    "cac", "churn", "segmentation", "a/b test", "split test",
    "compound", "periodization", "progressive overload", "macro",
    "advanced", "experienced", "years of",
    "deload", "volume management", "intensity techniques", "biomechanics",
    "autoregulation", "rpe", "rir", "mesocycle", "peaking",
    "diminishing returns", "marginal gains", "optimization curve",
  ],
} as const;

export const INTENT_KEYWORDS = {
  CURIOSITY: [
    "what do you think", "thoughts on", "curious", "interesting",
    "how does", "tell me more", "explain", "what about",
    "شو رأيك", "كيف يعني", "حابب أعرف",
    "wondering", "fascinated", "intrigued", "hmm", "really",
    "is that true", "seriously", "no way", "for real",
    "cool", "awesome", "wow", "amazing", "interesting take",
  ],
  LEARNING: [
    "how to", "tips", "advice", "guide", "tutorial", "teach me",
    "learn", "educate", "information", "resource",
    "كيف أعمل", "نصيحة", "علمني",
    "how do i", "best way to", "what's the best", "anyone know how",
    "step by step", "walk me through", "instructions", "help me understand",
    "show me", "demonstrate", "example", "practice", "training",
    "any tips", "anyone tried", "does this work", "what works best",
  ],
  COMPARISON: [
    "vs", "versus", "compared to", "better than", "difference between",
    "which one", "or", "alternative", "instead of", "switch from",
    "أو", "أفضل من", "الفرق بين",
    "which is better", "pros and cons", "head to head", "side by side",
    "competitor", "similar to", "like", "equivalent", "substitute",
    "upgrade from", "downgrade", "cheaper version", "premium vs basic",
  ],
  PURCHASE_INTENT: [
    "price", "cost", "buy", "purchase", "where can i get",
    "link", "discount", "how much", "available", "shipping",
    "order", "subscribe", "sign up", "enroll", "join",
    "كم سعره", "وين أشتري", "بدي أسجل",
    "coupon", "promo code", "sale", "deal", "offer",
    "checkout", "add to cart", "payment", "invoice", "billing",
    "free trial", "demo", "sample", "money back", "guarantee",
    "take my money", "shut up and take", "where do i pay", "instant access",
  ],
} as const;

export const LANGUAGE_PATTERNS = {
  PROBLEM_EXPRESSIONS: [
    "i can't", "i struggle", "my problem", "issue with", "frustrated",
    "not working", "help me", "stuck with", "dealing with", "suffering",
    "can't figure out", "hard to", "difficult to", "impossible to",
    "مشكلتي", "ما بقدر", "صعب", "مش شغال",
    "why isn't", "what's wrong", "keeps failing", "broken",
    "doesn't work", "won't load", "crashes", "error",
    "annoying", "terrible", "awful", "horrible", "worst",
    "pain point", "headache", "nightmare", "disaster",
    "how do i fix", "need to solve", "struggling with", "can't get past",
  ],
  QUESTION_PATTERNS: [
    "how do", "what is", "why does", "can someone", "anyone know",
    "is it possible", "should i", "when should", "where can", "who has",
    "does anyone", "has anyone", "any tips", "any advice", "suggestions",
    "كيف", "شو", "ليش", "مين", "وين", "إيمتى",
    "how", "why", "what", "when", "where", "who", "which",
    "can you", "could you", "would you", "will this", "does this",
    "any recommendations", "anyone tried", "what's the best",
    "have you", "do you know", "is there", "are there",
    "?",
  ],
  GOAL_EXPRESSIONS: [
    "i want to", "my goal is", "trying to", "hoping to", "planning to",
    "dream of", "wish i could", "working towards", "aiming for", "looking to",
    "need to", "have to", "must", "gonna", "going to",
    "بدي", "بدنا", "هدفي", "نفسي", "حابب",
    "determined to", "committed to", "focused on", "dedicated to",
    "by the end of", "this year i will", "my resolution", "bucket list",
    "on a mission", "dead set on", "no matter what", "whatever it takes",
    "manifesting", "visualizing", "affirming", "intending to",
  ],
} as const;

export const MAX_EXPECTED_SOURCE_TYPES = 5;

export const SOURCE_QUALITY_WEIGHTS = {
  REVIEW: 1.4,
  TIKTOK: 0.9,
  CAPTION: 1.0,
} as const;

export const CONFIDENCE_WEIGHTS = {
  SIGNAL_FREQUENCY: 0.5,
  SOURCE_DIVERSITY: 0.3,
  COMPETITOR_OVERLAP: 0.2,
} as const;
