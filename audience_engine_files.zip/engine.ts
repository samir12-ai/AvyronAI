import { db } from "../db";
import { audienceSnapshots, miSnapshots, ciCompetitors, ciCompetitorPosts, ciCompetitorComments, ciCompetitorReviews, growthCampaigns } from "@shared/schema";
import { loadProductDNA, formatProductDNAForPrompt } from "../shared/product-dna";
import { inArray, eq, and, desc, sql } from "drizzle-orm";
import {
  AUDIENCE_ENGINE_VERSION,
  AUDIENCE_THRESHOLDS,
  PAIN_CLUSTERS,
  DESIRE_CLUSTERS,
  OBJECTION_CLUSTERS,
  TRANSFORMATION_PATTERNS,
  EMOTIONAL_DRIVER_PATTERNS,
  AWARENESS_PATTERNS,
  MATURITY_KEYWORDS,
  INTENT_KEYWORDS,
  LANGUAGE_PATTERNS,
  SYNTHETIC_FILTERS,
  CONFIDENCE_WEIGHTS,
  OBJECTION_CONTEXT_RULES,
  MIN_EVIDENCE_PER_SIGNAL,
  BRIDGE_SUPPRESS_THRESHOLD,
  COMMENT_QUALITY_WEIGHTS,
  LOW_SIGNAL_COMMENT_PHRASES,
  MAX_EXPECTED_SOURCE_TYPES,
  SOURCE_QUALITY_WEIGHTS,
  type PatternCluster,
  type MarketScope,
} from "./constants";
import { MI_COST_LIMITS } from "../market-intelligence-v3/constants";
import { pruneOldSnapshots, assessDataReliability as sharedAssessDataReliability, normalizeConfidence as sharedNormalizeConfidence, detectGenericOutput } from "../engine-hardening";
import { aiChat } from "../ai-client";
import { createSourceLineageEntry, type SignalLineageEntry } from "../shared/signal-lineage";
import { executeSemanticBridge, mergeBridgedIntoAudienceMap, validateBridgeIntegrity, type SemanticBridgeResult } from "./semantic-bridge";
import { scoreAudienceSophistication, type AudienceSophisticationOutput } from "./sophistication-llm";

interface EvidenceMeta {
  evidenceCount: number;
  confidenceScore: number;
  sourceSignals: string[];
  inputSnapshotId: string | null;
}

interface SignalItem extends EvidenceMeta {
  canonical: string;
  frequency: number;
  evidence: string[];
}

interface LanguageSignals extends EvidenceMeta {
  problemExpressions: { count: number; samples: string[] };
  questionPatterns: { count: number; samples: string[] };
  goalExpressions: { count: number; samples: string[] };
  totalAnalyzed: number;
}

interface AwarenessResult extends EvidenceMeta {
  level: "unaware" | "problem_aware" | "solution_aware" | "product_aware" | "most_aware" | "insufficient_signals";
  distribution: Record<string, number>;
}

interface MaturityResult extends EvidenceMeta {
  level: "beginner" | "developing" | "mature" | "insufficient_signals";
  distribution: Record<string, number>;
  indicators: string[];
}

interface IntentDistribution extends EvidenceMeta {
  curiosity: number;
  learning: number;
  comparison: number;
  purchaseIntent: number;
  totalClassified: number;
}

interface AudienceSegment extends EvidenceMeta {
  name: string;
  description: string;
  painProfile: string[];
  desireProfile: string[];
  objectionProfile: string[];
  motivationProfile: string[];
  estimatedPercentage: number;
}

interface SegmentDensityItem extends EvidenceMeta {
  segment: string;
  densityScore: number;
  signalCount: number;
}

interface AdsTargetingHint extends EvidenceMeta {
  suggestedInterests: string[];
  suggestedBehaviors: string[];
  suggestedAgeRange: { min: number; max: number };
  suggestedGender: string;
  suggestedLocations: string[];
  rationale: string;
}

export interface StructuredSignalCluster {
  id: string;
  label: string;
  frequency: number;
  confidence: number;
  evidence: string[];
  sourceLayer: "surface" | "pattern" | "interpretation";
}

export interface StructuredSignals {
  pain_clusters: StructuredSignalCluster[];
  desire_clusters: StructuredSignalCluster[];
  pattern_clusters: StructuredSignalCluster[];
  root_causes: StructuredSignalCluster[];
  psychological_drivers: StructuredSignalCluster[];
}

// `PARTIAL` added: emitted when the engine
// produced usable output but signal coverage was below the qualifying
// threshold (or only some downstream maps populated). Distinct from
// INSUFFICIENT_SIGNALS (no usable output) and DEFENSIVE_MODE (low-trust).
// Downstream consumers (System Control, snapshot reuse) treat PARTIAL as
// "use with caution" — never as COMPLETE.
export type EngineStatus = "COMPLETE" | "PARTIAL" | "DATASET_TOO_SMALL" | "INSUFFICIENT_SIGNALS" | "DEFENSIVE_MODE" | "MISSING_DEPENDENCY";

export interface AudienceEngineV3Result {
  status: EngineStatus;
  statusMessage: string | null;
  defensiveMode: boolean;
  languageSignals: LanguageSignals;
  painMap: SignalItem[];
  desireMap: SignalItem[];
  objectionMap: SignalItem[];
  transformationMap: SignalItem[];
  emotionalDrivers: SignalItem[];
  audienceSegments: AudienceSegment[];
  segmentDensity: SegmentDensityItem[];
  awarenessLevel: AwarenessResult;
  maturityIndex: MaturityResult;
  intentDistribution: IntentDistribution;
  adsTargetingHints: AdsTargetingHint[];
  structuredSignals: StructuredSignals;
  inputSummary: {
    postsAnalyzed: number;
    commentsAnalyzed: number;
    competitorsAnalyzed: number;
    sanitizedCount: number;
    miSnapshotId: string | null;
    miSnapshotAge: string | null;
    semanticBridge?: {
      totalIngested: number;
      totalPassed: number;
      conflictsResolved: number;
      bridgeIntegrity: boolean;
      cleanPipeEnforced: boolean;
    };
  };
  engineVersion: number;
  executionTimeMs: number;
  snapshotId: string;
  audienceSophistication?: import("./sophistication-llm").AudienceSophisticationOutput | null;
  buyerPsychologyProfile?: import("./buyer-psychology").BuyerPsychologyProfile | null;
}

function sanitizeTexts(texts: string[]): { clean: string[]; removed: number } {
  let removed = 0;
  const clean: string[] = [];
  for (const text of texts) {
    const lower = text.toLowerCase();
    let isSynthetic = false;
    for (const filter of SYNTHETIC_FILTERS) {
      if (lower.includes(filter)) {
        isSynthetic = true;
        removed++;
        break;
      }
    }
    if (!isSynthetic) {
      clean.push(text);
    }
  }
  return { clean, removed };
}

type CommentQuality = "HIGH" | "MEDIUM" | "LOW" | "NOISE";

interface LabeledText {
  text: string;
  source: string;
  qualityWeight: number;
}

const EMOJI_ONLY_REGEX = /^[\p{Emoji}\p{Z}\s!?.,"']+$/u;
const SUBSTANTIVE_MARKER_REGEX = /\?|how|why|what|when|where|help|problem|issue|struggle|tried|can't|doesn't|not working|advice|question|difficult|challenge|frustrat|confus|overwhelm/i;

function classifyCommentQuality(text: string): CommentQuality {
  const trimmed = text.trim();
  const lower = trimmed.toLowerCase();

  if (trimmed.length < 8) return "NOISE";
  if (EMOJI_ONLY_REGEX.test(trimmed)) return "NOISE";

  const isLowPhrase = (LOW_SIGNAL_COMMENT_PHRASES as readonly string[]).some(p =>
    lower.includes(p) && trimmed.length < 40
  );
  if (isLowPhrase) return "LOW";

  if (SUBSTANTIVE_MARKER_REGEX.test(lower)) return "HIGH";
  if (trimmed.length > 80) return "HIGH";
  if (trimmed.length > 30) return "MEDIUM";

  return "LOW";
}

function buildLabeledComments(comments: string[]): {
  labeled: LabeledText[];
  noiseCount: number;
  lowCount: number;
  highCount: number;
  mediumCount: number;
} {
  const labeled: LabeledText[] = [];
  let noiseCount = 0;
  let lowCount = 0;
  let highCount = 0;
  let mediumCount = 0;

  for (const text of comments) {
    const quality = classifyCommentQuality(text);
    if (quality === "NOISE") {
      noiseCount++;
      continue;
    }
    const qualityWeight =
      quality === "HIGH"
        ? COMMENT_QUALITY_WEIGHTS.HIGH
        : quality === "MEDIUM"
        ? COMMENT_QUALITY_WEIGHTS.MEDIUM
        : COMMENT_QUALITY_WEIGHTS.LOW;

    if (quality === "HIGH") highCount++;
    else if (quality === "MEDIUM") mediumCount++;
    else lowCount++;

    labeled.push({ text, source: "comment", qualityWeight });
  }

  return { labeled, noiseCount, lowCount, highCount, mediumCount };
}

function buildLabeledCaptions(captions: string[]): LabeledText[] {
  return captions.map(text => ({ text, source: "caption", qualityWeight: SOURCE_QUALITY_WEIGHTS.CAPTION }));
}

function buildLabeledReviews(reviews: string[]): LabeledText[] {
  const labeled: LabeledText[] = [];
  for (const text of reviews) {
    const quality = classifyCommentQuality(text);
    if (quality === "NOISE") continue;
    const baseWeight =
      quality === "HIGH"
        ? COMMENT_QUALITY_WEIGHTS.HIGH
        : quality === "MEDIUM"
        ? COMMENT_QUALITY_WEIGHTS.MEDIUM
        : COMMENT_QUALITY_WEIGHTS.LOW;
    labeled.push({ text, source: "review", qualityWeight: baseWeight * SOURCE_QUALITY_WEIGHTS.REVIEW });
  }
  return labeled;
}

function buildLabeledTiktok(tiktokTexts: string[]): LabeledText[] {
  return tiktokTexts
    .filter(t => t.trim().length >= 5)
    .map(text => ({ text, source: "tiktok", qualityWeight: SOURCE_QUALITY_WEIGHTS.TIKTOK }));
}

function computePrimaryDataStrength(
  labeledComments: LabeledText[],
  labeledCaptions: LabeledText[],
): number {
  const totalLabeled = labeledComments.length + labeledCaptions.length;
  if (totalLabeled === 0) return 0;

  const highQualityComments = labeledComments.filter(t => t.qualityWeight >= COMMENT_QUALITY_WEIGHTS.HIGH).length;
  const uniqueSources = new Set<string>();
  if (labeledComments.length > 0) uniqueSources.add("comment");
  if (labeledCaptions.length > 0) uniqueSources.add("caption");

  const volumeScore = Math.min(1, totalLabeled / 80);
  const qualityScore = labeledComments.length > 0
    ? Math.min(1, highQualityComments / Math.max(labeledComments.length, 1))
    : 0.4;
  const sourceScore = Math.min(1, uniqueSources.size / 2);
  const captionScore = Math.min(1, labeledCaptions.length / 20);

  return (
    volumeScore * 0.35 +
    qualityScore * 0.25 +
    sourceScore * 0.20 +
    captionScore * 0.20
  );
}

const MARKET_DETECTION_KEYWORDS: Record<MarketScope, string[]> = {
  fitness: ["workout", "exercise", "gym", "training", "muscle", "body", "weight loss", "bulk", "lean", "cardio", "تمرين", "رياضة", "جيم"],
  health: ["health", "nutrition", "diet", "wellness", "medical", "therapy", "condition", "صحة", "تغذية", "علاج"],
  marketing: ["marketing", "brand", "audience", "content", "social media", "ads", "campaign", "تسويق", "علامة تجارية"],
  ecommerce: ["store", "product", "shop", "buy", "sell", "ecommerce", "dropship", "متجر", "منتج"],
  education: ["course", "learn", "student", "teacher", "school", "education", "certificate", "تعليم", "دورة", "طالب"],
  finance: ["invest", "stock", "crypto", "money", "wealth", "trading", "portfolio", "استثمار", "مال"],
  tech: ["software", "app", "code", "developer", "startup", "saas", "tech", "تقنية", "برمجة"],
  beauty: ["beauty", "skin", "makeup", "cosmetic", "hair", "skincare", "جمال", "بشرة", "مكياج"],
  food: ["recipe", "cook", "restaurant", "food", "bake", "chef", "طبخ", "أكل", "مطعم"],
  universal: [],
};

interface MarketScopeMetadata {
  scopeConfidence: number;
  matchedKeywordDensity: number;
  scopeAmbiguityFlag: boolean;
}

function getMarketScopeMetadata(): MarketScopeMetadata {
  return { scopeConfidence: 0, matchedKeywordDensity: 0, scopeAmbiguityFlag: false };
}

function detectMarketScope(
  texts: string[],
  businessContext: { industry: string; coreOffer: string },
): { markets: MarketScope[]; metadata: MarketScopeMetadata } {
  const allText = [...texts.slice(0, 200), businessContext.industry, businessContext.coreOffer].join(" ").toLowerCase();
  const totalWords = allText.split(/\s+/).length || 1;
  const scores: Record<MarketScope, number> = {} as any;

  let totalKeywordMatches = 0;
  for (const [scope, keywords] of Object.entries(MARKET_DETECTION_KEYWORDS)) {
    if (scope === "universal") continue;
    let count = 0;
    for (const kw of keywords) {
      const regex = new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      const matches = allText.match(regex);
      if (matches) count += matches.length;
    }
    scores[scope as MarketScope] = count;
    totalKeywordMatches += count;
  }

  const matchedKeywordDensity = Math.min(1, totalKeywordMatches / totalWords);

  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]).filter(([, v]) => v > 0);
  if (sorted.length === 0) {
    return {
      markets: ["universal"],
      metadata: { scopeConfidence: 0, matchedKeywordDensity: 0, scopeAmbiguityFlag: false },
    };
  }

  const topScore = sorted[0][1];
  const secondScore = sorted[1]?.[1] || 0;

  const scopeAmbiguityFlag = secondScore > 0 && (topScore - secondScore) / topScore < 0.20;

  const separationFactor = secondScore > 0 ? (topScore - secondScore) / topScore : 1;
  const densityFactor = Math.min(1, totalKeywordMatches / 10);
  const scopeConfidence = Math.round(Math.min(1, Math.max(0, separationFactor * 0.5 + densityFactor * 0.5)) * 1000) / 1000;

  const detected = sorted.filter(([, v]) => v >= topScore * 0.3).map(([k]) => k as MarketScope);
  return {
    markets: detected.length > 0 ? detected : ["universal"],
    metadata: { scopeConfidence, matchedKeywordDensity, scopeAmbiguityFlag },
  };
}

function filterClustersByMarket(clusters: PatternCluster[], detectedMarkets: MarketScope[]): PatternCluster[] {
  return clusters.filter(cluster => {
    if (!cluster.marketScope) return true;
    if (detectedMarkets.includes("universal")) return true;
    return cluster.marketScope.some(s => detectedMarkets.includes(s));
  });
}

function applyObjectionContextRules(
  objectionMap: SignalItem[],
  texts: string[],
): SignalItem[] {
  const allTextLower = texts.join(" ").toLowerCase();

  const result: SignalItem[] = [];
  const fallbackMerge = new Map<string, SignalItem>();

  for (const item of objectionMap) {
    const rule = OBJECTION_CONTEXT_RULES[item.canonical];
    if (!rule) {
      result.push(item);
      continue;
    }

    const hasContext = rule.requireKeywords.some(kw => allTextLower.includes(kw.toLowerCase()));
    if (hasContext) {
      result.push(item);
      continue;
    }

    const existing = fallbackMerge.get(rule.fallbackCanonical);
    if (existing) {
      existing.frequency += item.frequency;
      existing.evidenceCount += item.evidenceCount;
      existing.evidence = [...existing.evidence, ...item.evidence].slice(0, 3);
      existing.confidenceScore = Math.max(existing.confidenceScore, item.confidenceScore);
    } else {
      const existingInResult = result.find(r => r.canonical === rule.fallbackCanonical);
      if (existingInResult) {
        existingInResult.frequency += item.frequency;
        existingInResult.evidenceCount += item.evidenceCount;
        existingInResult.evidence = [...existingInResult.evidence, ...item.evidence].slice(0, 3);
      } else {
        fallbackMerge.set(rule.fallbackCanonical, { ...item, canonical: rule.fallbackCanonical });
      }
    }
  }

  for (const [, merged] of fallbackMerge) {
    result.push(merged);
  }

  return result;
}

function buildNarrativeObjectionSignals(
  latestSnapshot: any,
  miSnapshotId: string | null,
): SignalItem[] {
  if (!latestSnapshot?.objectionMapData) return [];
  let miObjMap: any = null;
  try {
    miObjMap = typeof latestSnapshot.objectionMapData === "string"
      ? JSON.parse(latestSnapshot.objectionMapData)
      : latestSnapshot.objectionMapData;
  } catch { return []; }
  const narrativeObjections: any[] = Array.isArray(miObjMap?.objections) ? miObjMap.objections : [];
  if (narrativeObjections.length === 0) return [];

  const signals: SignalItem[] = [];
  for (const obj of narrativeObjections) {
    const canonical = typeof obj?.objection === "string" ? obj.objection.trim() : "";
    if (!canonical) continue;
    const supporting: any[] = Array.isArray(obj.supportingEvidence) ? obj.supportingEvidence : [];
    const competitorSources: string[] = Array.isArray(obj.competitorSources) ? obj.competitorSources : [];
    const evidenceTexts = supporting
      .map((e: any) => (typeof e?.caption === "string" ? e.caption.slice(0, 200) : ""))
      .filter((s: string) => s.length > 0)
      .slice(0, 3);
    const evidenceCount = Math.max(supporting.length, evidenceTexts.length);
    const frequency = Math.max(supporting.length, competitorSources.length, 1);
    const confidenceScore = typeof obj.narrativeConfidence === "number" ? obj.narrativeConfidence : 0.3;
    const matchedPatterns = supporting
      .map((e: any) => (typeof e?.matchedPattern === "string" ? `narrative:${e.matchedPattern}` : null))
      .filter((s: string | null): s is string => !!s)
      .slice(0, 5);
    signals.push({
      canonical,
      frequency,
      evidence: evidenceTexts,
      evidenceCount,
      confidenceScore,
      sourceSignals: ["narrative_objection_extractor", obj.signalType || "objection", obj.patternCategory || "unclassified", ...matchedPatterns],
      inputSnapshotId: miSnapshotId,
    });
  }
  return signals;
}

function mergeNarrativeObjectionsIntoMap(
  existing: SignalItem[],
  narrative: SignalItem[],
): { merged: SignalItem[]; added: number; reinforced: number } {
  if (narrative.length === 0) return { merged: existing, added: 0, reinforced: 0 };
  const byKey = new Map<string, SignalItem>();
  for (const s of existing) {
    byKey.set(s.canonical.toLowerCase(), { ...s });
  }
  let added = 0;
  let reinforced = 0;
  for (const narr of narrative) {
    const key = narr.canonical.toLowerCase();
    const prev = byKey.get(key);
    if (prev) {
      prev.frequency += narr.frequency;
      prev.evidenceCount += narr.evidenceCount;
      for (const ev of narr.evidence) {
        if (prev.evidence.length < 3 && !prev.evidence.includes(ev)) prev.evidence.push(ev);
      }
      prev.confidenceScore = Math.max(prev.confidenceScore, narr.confidenceScore);
      for (const src of narr.sourceSignals) {
        if (!prev.sourceSignals.includes(src)) prev.sourceSignals.push(src);
      }
      reinforced++;
    } else {
      byKey.set(key, { ...narr });
      added++;
    }
  }
  const merged = Array.from(byKey.values()).sort((a, b) => b.confidenceScore - a.confidenceScore);
  return { merged, added, reinforced };
}

function applyEvidenceIntegrityFilter(signals: SignalItem[]): SignalItem[] {
  return signals.map(s => {
    if (s.evidenceCount >= MIN_EVIDENCE_PER_SIGNAL && s.frequency >= MIN_EVIDENCE_PER_SIGNAL) {
      return s;
    }
    if (s.evidenceCount >= 1 || s.frequency >= 1) {
      const evidenceRatio = Math.min(s.evidenceCount, s.frequency) / MIN_EVIDENCE_PER_SIGNAL;
      // no synthetic confidence floor. If the
      // raw signal already carries 0 confidence, the downgrade emits 0 — we
      // never invent a 0.05 minimum. Honest zero is better than a fabricated
      // pulse that downstream gates can clear.
      const downgradedConfidence = s.confidenceScore * evidenceRatio * 0.6;
      return {
        ...s,
        confidenceScore: downgradedConfidence,
        sourceSignals: [...s.sourceSignals, "evidence_downgraded"],
      };
    }
    return null;
  }).filter((s): s is SignalItem => s !== null);
}

function inferPainsFromObjections(objectionMap: SignalItem[], inputSnapshotId: string | null): SignalItem[] {
  const inferred: SignalItem[] = [];
  for (const obj of objectionMap) {
    const painCanonical = `Problem behind objection: ${obj.canonical}`;
    inferred.push({
      canonical: painCanonical,
      frequency: Math.max(1, Math.round(obj.frequency * 0.7)),
      evidence: obj.evidence.slice(0, 2),
      evidenceCount: Math.max(1, Math.round(obj.evidenceCount * 0.7)),
      // no 0.1 floor — inferred confidence is a strict multiple of the
      // source objection's confidence. If the source is zero, the inference is zero.
      confidenceScore: obj.confidenceScore * 0.6,
      sourceSignals: [...obj.sourceSignals, "inferred_from_objection"],
      inputSnapshotId,
    });
  }
  return inferred;
}

function inferPainsFromEmotionalDrivers(drivers: SignalItem[], inputSnapshotId: string | null): SignalItem[] {
  const inferred: SignalItem[] = [];
  for (const driver of drivers) {
    const painCanonical = `Unresolved need: ${driver.canonical}`;
    inferred.push({
      canonical: painCanonical,
      frequency: Math.max(1, Math.round(driver.frequency * 0.5)),
      evidence: driver.evidence.slice(0, 2),
      evidenceCount: Math.max(1, Math.round(driver.evidenceCount * 0.5)),
      // no 0.1 floor — see inferPainsFromObjections.
      confidenceScore: driver.confidenceScore * 0.5,
      sourceSignals: [...driver.sourceSignals, "inferred_from_emotional_driver"],
      inputSnapshotId,
    });
  }
  return inferred;
}

function mergePainLayers(
  directPains: SignalItem[],
  objectionInferred: SignalItem[],
  driverInferred: SignalItem[],
  bridgePains: SignalItem[],
): { finalPainMap: SignalItem[]; painSources: { direct: number; objectionInferred: number; driverInferred: number; bridge: number } } {
  const seen = new Set<string>();
  const final: SignalItem[] = [];

  for (const p of directPains) {
    seen.add(p.canonical.toLowerCase());
    final.push(p);
  }

  for (const p of bridgePains) {
    const key = p.canonical.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      final.push(p);
    }
  }

  for (const p of objectionInferred) {
    const key = p.canonical.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      final.push(p);
    }
  }

  for (const p of driverInferred) {
    const key = p.canonical.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      final.push(p);
    }
  }

  final.sort((a, b) => b.confidenceScore - a.confidenceScore);

  return {
    finalPainMap: final,
    painSources: {
      direct: directPains.length,
      objectionInferred: objectionInferred.filter(p => final.includes(p)).length,
      driverInferred: driverInferred.filter(p => final.includes(p)).length,
      bridge: bridgePains.filter(p => final.includes(p)).length,
    },
  };
}

function computeSegmentSimilarity(segA: AudienceSegment, segB: AudienceSegment): number {
  const tokensA = new Set([
    ...segA.name.toLowerCase().split(/\s+/),
    ...segA.painProfile.map(p => p.toLowerCase()),
    ...segA.desireProfile.map(d => d.toLowerCase()),
    ...(segA.objectionProfile || []).map(o => o.toLowerCase()),
    ...(segA.motivationProfile || []).map(m => m.toLowerCase()),
  ]);
  const tokensB = new Set([
    ...segB.name.toLowerCase().split(/\s+/),
    ...segB.painProfile.map(p => p.toLowerCase()),
    ...segB.desireProfile.map(d => d.toLowerCase()),
    ...(segB.objectionProfile || []).map(o => o.toLowerCase()),
    ...(segB.motivationProfile || []).map(m => m.toLowerCase()),
  ]);

  let intersection = 0;
  for (const t of tokensA) {
    if (tokensB.has(t)) intersection++;
  }
  const union = new Set([...tokensA, ...tokensB]).size;
  return union > 0 ? intersection / union : 0;
}

function canonicalizeSegments(segments: AudienceSegment[]): AudienceSegment[] {
  if (segments.length <= 1) return segments;

  const SIMILARITY_THRESHOLD = 0.80;
  const MAX_SEGMENTS = 4;

  const merged: AudienceSegment[] = [];
  const used = new Set<number>();

  for (let i = 0; i < segments.length; i++) {
    if (used.has(i)) continue;

    let canonical = { ...segments[i] };
    const mergeGroup = [segments[i]];

    for (let j = i + 1; j < segments.length; j++) {
      if (used.has(j)) continue;
      const similarity = computeSegmentSimilarity(canonical, segments[j]);
      if (similarity >= SIMILARITY_THRESHOLD) {
        mergeGroup.push(segments[j]);
        used.add(j);
      }
    }

    if (mergeGroup.length > 1) {
      const best = mergeGroup.sort((a, b) => (b.estimatedPercentage || 0) - (a.estimatedPercentage || 0))[0];
      const combinedPercentage = mergeGroup.reduce((s, seg) => s + (seg.estimatedPercentage || 0), 0);
      const allPains = [...new Set(mergeGroup.flatMap(s => s.painProfile))];
      const allDesires = [...new Set(mergeGroup.flatMap(s => s.desireProfile))];
      const allObjections = [...new Set(mergeGroup.flatMap(s => s.objectionProfile || []))];
      const allMotivations = [...new Set(mergeGroup.flatMap(s => s.motivationProfile || []))];
      const allSourceSignals = [...new Set(mergeGroup.flatMap(s => s.sourceSignals || []))];
      const totalEvidence = mergeGroup.reduce((s, seg) => s + (seg.evidenceCount || 0), 0);

      canonical = {
        ...best,
        estimatedPercentage: combinedPercentage,
        painProfile: allPains,
        desireProfile: allDesires,
        objectionProfile: allObjections,
        motivationProfile: allMotivations,
        evidenceCount: totalEvidence,
        confidenceScore: Math.min(0.95, (best.confidenceScore || 0.5) + mergeGroup.length * 0.05),
        sourceSignals: allSourceSignals,
      };
    }

    merged.push(canonical);
    used.add(i);
  }

  if (merged.length <= MAX_SEGMENTS) return merged;

  const sorted = merged.sort((a, b) => (b.estimatedPercentage || 0) - (a.estimatedPercentage || 0));
  const kept = sorted.slice(0, MAX_SEGMENTS - 1);
  const overflow = sorted.slice(MAX_SEGMENTS - 1);

  const overflowPercentage = overflow.reduce((s, seg) => s + (seg.estimatedPercentage || 0), 0);
  const overflowEvidence = overflow.reduce((s, seg) => s + (seg.evidenceCount || 0), 0);

  kept.push({
    name: "Secondary Segment Cluster",
    description: `Merged cluster of ${overflow.length} smaller audience segments`,
    painProfile: [...new Set(overflow.flatMap(s => s.painProfile).slice(0, 5))],
    desireProfile: [...new Set(overflow.flatMap(s => s.desireProfile).slice(0, 5))],
    objectionProfile: [...new Set(overflow.flatMap(s => s.objectionProfile || []).slice(0, 3))],
    motivationProfile: [...new Set(overflow.flatMap(s => s.motivationProfile || []).slice(0, 3))],
    estimatedPercentage: overflowPercentage,
    evidenceCount: overflowEvidence,
    confidenceScore: 0.3,
    sourceSignals: ["merged-overflow"],
    inputSnapshotId: overflow[0]?.inputSnapshotId || null,
  });

  return kept;
}

function computeCalibratedConfidence(
  frequency: number,
  totalTexts: number,
  sourceTypes: string[],
  competitorCount: number,
): number {
  const freqScore = totalTexts > 0 ? Math.min(1, frequency / Math.max(totalTexts * 0.1, 1)) : 0;
  const diversityScore = Math.min(1, sourceTypes.length / MAX_EXPECTED_SOURCE_TYPES);
  const competitorScore = Math.min(1, competitorCount / MI_COST_LIMITS.MAX_COMPETITORS);

  const raw =
    freqScore * CONFIDENCE_WEIGHTS.SIGNAL_FREQUENCY +
    diversityScore * CONFIDENCE_WEIGHTS.SOURCE_DIVERSITY +
    competitorScore * CONFIDENCE_WEIGHTS.COMPETITOR_OVERLAP;

  return Math.min(0.95, Math.max(0.05, raw));
}

function matchPatternClusters(
  labeledTexts: LabeledText[],
  clusters: PatternCluster[],
  inputSnapshotId: string | null,
  competitorCount: number,
): SignalItem[] {
  const results: Map<string, {
    weightedCount: number;
    rawCount: number;
    evidence: string[];
    matchedPatterns: Set<string>;
    hitSources: Set<string>;
  }> = new Map();

  for (const cluster of clusters) {
    results.set(cluster.canonical, {
      weightedCount: 0,
      rawCount: 0,
      evidence: [],
      matchedPatterns: new Set(),
      hitSources: new Set(),
    });
  }

  const totalWeightedTexts = labeledTexts.reduce((sum, t) => sum + t.qualityWeight, 0);

  for (const { text, source, qualityWeight } of labeledTexts) {
    const lower = text.toLowerCase();
    for (const cluster of clusters) {
      for (const pattern of cluster.patterns) {
        if (lower.includes(pattern)) {
          const entry = results.get(cluster.canonical)!;
          entry.weightedCount += qualityWeight;
          entry.rawCount++;
          entry.matchedPatterns.add(pattern);
          entry.hitSources.add(source);
          if (entry.evidence.length < 3) {
            entry.evidence.push(text.slice(0, 150));
          }
          break;
        }
      }
    }
  }

  return Array.from(results.entries())
    .filter(([, v]) => v.rawCount > 0)
    .sort((a, b) => b[1].weightedCount - a[1].weightedCount)
    .map(([canonical, data]) => ({
      canonical,
      frequency: Math.round(data.weightedCount),
      evidence: data.evidence,
      evidenceCount: data.rawCount,
      confidenceScore: computeCalibratedConfidence(
        data.weightedCount,
        totalWeightedTexts,
        Array.from(data.hitSources),
        competitorCount,
      ),
      sourceSignals: Array.from(data.matchedPatterns),
      inputSnapshotId,
    }));
}

function analyzeLanguage(
  comments: string[],
  captions: string[],
  inputSnapshotId: string | null,
  competitorCount: number,
  reviews: string[] = [],
  tiktokTexts: string[] = [],
): LanguageSignals {
  const allText = [...comments, ...captions, ...reviews, ...tiktokTexts];
  const result: LanguageSignals = {
    problemExpressions: { count: 0, samples: [] },
    questionPatterns: { count: 0, samples: [] },
    goalExpressions: { count: 0, samples: [] },
    totalAnalyzed: allText.length,
    evidenceCount: 0,
    confidenceScore: 0,
    sourceSignals: [],
    inputSnapshotId,
  };

  for (const text of allText) {
    const lower = text.toLowerCase();

    for (const pattern of LANGUAGE_PATTERNS.PROBLEM_EXPRESSIONS) {
      if (lower.includes(pattern)) {
        result.problemExpressions.count++;
        if (result.problemExpressions.samples.length < 3) {
          result.problemExpressions.samples.push(text.slice(0, 120));
        }
        break;
      }
    }

    for (const pattern of LANGUAGE_PATTERNS.QUESTION_PATTERNS) {
      if (lower.includes(pattern)) {
        result.questionPatterns.count++;
        if (result.questionPatterns.samples.length < 3) {
          result.questionPatterns.samples.push(text.slice(0, 120));
        }
        break;
      }
    }

    for (const pattern of LANGUAGE_PATTERNS.GOAL_EXPRESSIONS) {
      if (lower.includes(pattern)) {
        result.goalExpressions.count++;
        if (result.goalExpressions.samples.length < 3) {
          result.goalExpressions.samples.push(text.slice(0, 120));
        }
        break;
      }
    }
  }

  const total = result.problemExpressions.count + result.questionPatterns.count + result.goalExpressions.count;
  result.evidenceCount = total;
  const sourceTypes = [];
  if (comments.length > 0) sourceTypes.push("comments");
  if (captions.length > 0) sourceTypes.push("captions");
  if (reviews.length > 0) sourceTypes.push("reviews");
  if (tiktokTexts.length > 0) sourceTypes.push("tiktok");
  result.confidenceScore = computeCalibratedConfidence(total, allText.length, sourceTypes, competitorCount);
  result.sourceSignals = sourceTypes;

  return result;
}

function detectAwareness(
  comments: string[],
  inputSnapshotId: string | null,
  competitorCount: number,
  miObjectionDensity: number = 0,
  miObjectionCount: number = 0,
): AwarenessResult {
  const distribution: Record<string, number> = {
    unaware: 0,
    problem_aware: 0,
    solution_aware: 0,
    product_aware: 0,
    most_aware: 0,
  };

  const levelKeys: [string, readonly string[]][] = [
    ["most_aware", AWARENESS_PATTERNS.MOST_AWARE],
    ["product_aware", AWARENESS_PATTERNS.PRODUCT_AWARE],
    ["solution_aware", AWARENESS_PATTERNS.SOLUTION_AWARE],
    ["problem_aware", AWARENESS_PATTERNS.PROBLEM_AWARE],
    ["unaware", AWARENESS_PATTERNS.UNAWARE],
  ];

  let totalMatched = 0;

  for (const text of comments) {
    const lower = text.toLowerCase();
    let matched = false;
    for (const [level, patterns] of levelKeys) {
      for (const p of patterns) {
        if (lower.includes(p)) {
          distribution[level]++;
          totalMatched++;
          matched = true;
          break;
        }
      }
      if (matched) break;
    }
  }

  if (totalMatched < 3) {
    if (miObjectionCount >= 3 && miObjectionDensity > 0.1) {
      return {
        level: "problem_aware",
        distribution: { problem_aware: 100 },
        evidenceCount: miObjectionCount,
        confidenceScore: Math.min(miObjectionDensity + 0.1, 0.6),
        sourceSignals: ["mi_narrative_objections"],
        inputSnapshotId,
      };
    }
    return {
      level: "insufficient_signals",
      distribution: {},
      evidenceCount: totalMatched,
      confidenceScore: 0,
      sourceSignals: ["comments"],
      inputSnapshotId,
    };
  }

  let dominantLevel = "problem_aware";
  let maxCount = 0;
  for (const [level, count] of Object.entries(distribution)) {
    if (count > maxCount) {
      maxCount = count;
      dominantLevel = level;
    }
  }

  if (dominantLevel === "unaware" && miObjectionCount >= 3 && miObjectionDensity > 0.15) {
    const problemAwareCount = distribution["problem_aware"] || 0;
    const solutionAwareCount = distribution["solution_aware"] || 0;
    if (solutionAwareCount > problemAwareCount && solutionAwareCount > 0) {
      dominantLevel = "solution_aware";
    } else {
      dominantLevel = "problem_aware";
    }
    console.log(`[AudienceEngine-V3] OBJECTION_DENSITY_OVERRIDE | miObjections=${miObjectionCount} | density=${miObjectionDensity} | overrideFrom=unaware | overrideTo=${dominantLevel}`);
  }

  const pct: Record<string, number> = {};
  for (const [level, count] of Object.entries(distribution)) {
    pct[level] = Math.round((count / totalMatched) * 100);
  }

  return {
    level: dominantLevel as AwarenessResult["level"],
    distribution: pct,
    evidenceCount: totalMatched,
    confidenceScore: computeCalibratedConfidence(totalMatched, comments.length, ["comments"], competitorCount),
    sourceSignals: ["comments"],
    inputSnapshotId,
  };
}

function detectMaturity(
  comments: string[],
  captions: string[],
  inputSnapshotId: string | null,
  competitorCount: number,
): MaturityResult {
  const allText = [...comments, ...captions];
  const signals = { beginner: 0, developing: 0, mature: 0 };
  const indicators: string[] = [];

  for (const text of allText) {
    const lower = text.toLowerCase();

    for (const kw of MATURITY_KEYWORDS.MATURE) {
      if (lower.includes(kw)) {
        signals.mature++;
        if (indicators.length < 5) indicators.push(kw);
        break;
      }
    }
    for (const kw of MATURITY_KEYWORDS.DEVELOPING) {
      if (lower.includes(kw)) { signals.developing++; break; }
    }
    for (const kw of MATURITY_KEYWORDS.BEGINNER) {
      if (lower.includes(kw)) { signals.beginner++; break; }
    }
  }

  const total = signals.beginner + signals.developing + signals.mature;

  if (total < 3) {
    return {
      level: "insufficient_signals",
      distribution: {},
      indicators: [],
      evidenceCount: total,
      confidenceScore: 0,
      sourceSignals: ["comments", "captions"],
      inputSnapshotId,
    };
  }

  const dist: Record<string, number> = {
    beginner: Math.round((signals.beginner / total) * 100),
    developing: Math.round((signals.developing / total) * 100),
    mature: Math.round((signals.mature / total) * 100),
  };

  let level: "beginner" | "developing" | "mature" = "beginner";
  if (signals.mature > signals.developing && signals.mature > signals.beginner) level = "mature";
  else if (signals.developing > signals.beginner) level = "developing";

  const sourceTypes = [];
  if (comments.length > 0) sourceTypes.push("comments");
  if (captions.length > 0) sourceTypes.push("captions");

  return {
    level,
    distribution: dist,
    indicators,
    evidenceCount: total,
    confidenceScore: computeCalibratedConfidence(total, allText.length, sourceTypes, competitorCount),
    sourceSignals: sourceTypes,
    inputSnapshotId,
  };
}

function classifyIntents(
  comments: string[],
  inputSnapshotId: string | null,
  competitorCount: number,
): IntentDistribution {
  let curiosity = 0;
  let learning = 0;
  let comparison = 0;
  let purchaseIntent = 0;
  let totalClassified = 0;

  for (const text of comments) {
    const lower = text.toLowerCase();
    let classified = false;

    for (const kw of INTENT_KEYWORDS.PURCHASE_INTENT) {
      if (lower.includes(kw)) { purchaseIntent++; classified = true; break; }
    }
    if (!classified) {
      for (const kw of INTENT_KEYWORDS.COMPARISON) {
        if (lower.includes(kw)) { comparison++; classified = true; break; }
      }
    }
    if (!classified) {
      for (const kw of INTENT_KEYWORDS.LEARNING) {
        if (lower.includes(kw)) { learning++; classified = true; break; }
      }
    }
    if (!classified) {
      for (const kw of INTENT_KEYWORDS.CURIOSITY) {
        if (lower.includes(kw)) { curiosity++; classified = true; break; }
      }
    }
    if (classified) totalClassified++;
  }

  if (totalClassified === 0) {
    return {
      curiosity: 0, learning: 0, comparison: 0, purchaseIntent: 0,
      totalClassified: 0,
      evidenceCount: 0,
      confidenceScore: 0,
      sourceSignals: ["comments"],
      inputSnapshotId,
    };
  }

  return {
    curiosity: Math.round((curiosity / totalClassified) * 100),
    learning: Math.round((learning / totalClassified) * 100),
    comparison: Math.round((comparison / totalClassified) * 100),
    purchaseIntent: Math.round((purchaseIntent / totalClassified) * 100),
    totalClassified,
    evidenceCount: totalClassified,
    confidenceScore: computeCalibratedConfidence(totalClassified, comments.length, ["comments"], competitorCount),
    sourceSignals: ["comments"],
    inputSnapshotId,
  };
}

type IntentTemperature = "cold" | "warm" | "hot" | "very_hot";

function deriveIntentTemperature(intentDist: IntentDistribution): IntentTemperature {
  if (intentDist.totalClassified === 0) return "cold";

  const weighted =
    intentDist.curiosity * 0.1 +
    intentDist.learning * 0.3 +
    intentDist.comparison * 0.6 +
    intentDist.purchaseIntent * 1.0;

  const normalizedTemp = weighted / 100;

  if (normalizedTemp >= 0.55) return "very_hot";
  if (normalizedTemp >= 0.35) return "hot";
  if (normalizedTemp >= 0.20) return "warm";
  return "cold";
}

function computeSegmentDensity(
  painMap: SignalItem[],
  desireMap: SignalItem[],
  segments: AudienceSegment[],
  inputSnapshotId: string | null,
): SegmentDensityItem[] {
  const totalSignals = painMap.reduce((s, p) => s + p.frequency, 0) + desireMap.reduce((s, d) => s + d.frequency, 0);

  const rawDensities = segments.map(seg => {
    let signalCount = 0;
    for (const pain of painMap) {
      if (seg.painProfile.some(p => pain.canonical.toLowerCase().includes(p.toLowerCase()))) {
        signalCount += pain.frequency;
      }
    }
    for (const desire of desireMap) {
      if (seg.desireProfile.some(d => desire.canonical.toLowerCase().includes(d.toLowerCase()))) {
        signalCount += desire.frequency;
      }
    }
    return { segment: seg.name, signalCount };
  });

  const rawTotal = rawDensities.reduce((s, d) => s + d.signalCount, 0);

  const items = rawDensities.map(d => ({
    segment: d.segment,
    rawDensity: rawTotal > 0 ? (d.signalCount / rawTotal) * 100 : 0,
    signalCount: d.signalCount,
  }));

  const floored = items.map(d => ({ ...d, densityScore: Math.floor(d.rawDensity) }));
  let remainder = 100 - floored.reduce((s, d) => s + d.densityScore, 0);
  const sorted = floored.map((d, i) => ({ ...d, idx: i, frac: d.rawDensity - d.densityScore }))
    .sort((a, b) => b.frac - a.frac);
  for (const item of sorted) {
    if (remainder <= 0) break;
    floored[item.idx].densityScore += 1;
    remainder--;
  }

  return floored.map(d => ({
    segment: d.segment,
    densityScore: rawTotal > 0 ? d.densityScore : 0,
    signalCount: d.signalCount,
    evidenceCount: d.signalCount,
    confidenceScore: rawTotal > 0 ? Math.min(0.95, d.signalCount / rawTotal) : 0,
    sourceSignals: ["painMap", "desireMap"],
    inputSnapshotId,
  }));
}

async function constructSegments(
  painMap: SignalItem[],
  desireMap: SignalItem[],
  objectionMap: SignalItem[],
  emotionalDrivers: SignalItem[],
  maturity: MaturityResult,
  awareness: AwarenessResult,
  businessContext: { industry: string; coreOffer: string; targetAudience: string },
  commentSamples: string[],
  accountId: string,
  inputSnapshotId: string | null,
): Promise<AudienceSegment[]> {
  try {
    let multiSourceSection = "";
    try {
      const { loadMultiSourceContext, buildMultiSourcePromptSection, buildSourceFallbackContext } = await import("../shared/multi-source-loader");
      if (inputSnapshotId) {
        const msCtx = await loadMultiSourceContext(inputSnapshotId);
        if (msCtx && (msCtx.hasMeaningfulWebData || msCtx.hasMeaningfulBlogData)) {
          multiSourceSection = buildMultiSourcePromptSection(msCtx);
          multiSourceSection += "\n\nIMPORTANT: Use website headlines and blog titles to infer audience pains even when comments are absent. Website copy reveals what the market responds to. Blog topics reveal what questions the audience asks repeatedly.";
        } else {
          multiSourceSection = buildSourceFallbackContext(msCtx);
        }
      }
    } catch {}

    const productDnaBlock = (businessContext as any).productDna ? formatProductDNAForPrompt((businessContext as any).productDna) : "";

    const prompt = `You are an audience research analyst. Based on market evidence, construct 2-4 distinct audience segments.

BUSINESS: ${businessContext.industry} — ${businessContext.coreOffer}
${productDnaBlock ? `\n${productDnaBlock}\n` : ""}

PAIN MAP (from real audience data):
${painMap.slice(0, 8).map(p => `- ${p.canonical}: frequency=${p.frequency}, confidence=${(p.confidenceScore * 100).toFixed(0)}%`).join("\n")}

DESIRE MAP:
${desireMap.slice(0, 8).map(d => `- ${d.canonical}: frequency=${d.frequency}`).join("\n")}

OBJECTION MAP:
${objectionMap.slice(0, 6).map(o => `- ${o.canonical}: frequency=${o.frequency}`).join("\n")}

EMOTIONAL DRIVERS:
${emotionalDrivers.slice(0, 6).map(e => `- ${e.canonical}: frequency=${e.frequency}`).join("\n")}

MARKET MATURITY: ${maturity.level}
AWARENESS LEVEL: ${awareness.level}
${multiSourceSection}

SAMPLE COMMENTS (real audience language):
${commentSamples.slice(0, 12).map(c => `"${c.slice(0, 100)}"`).join("\n")}

Return a JSON array of 2-4 segments. Each segment:
{
  "name": "segment name",
  "description": "brief description",
  "painProfile": ["pain1", "pain2"],
  "desireProfile": ["desire1", "desire2"],
  "objectionProfile": ["objection1"],
  "motivationProfile": ["motivation1", "motivation2"],
  "estimatedPercentage": number (must total ~100)
}

Return ONLY the JSON array, no markdown.`;

    const response = await aiChat({
      model: "gpt-4.1-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.4,
      max_tokens: 2000,
      endpoint: "audience-engine-v3-segments",
      accountId,
    });

    const content = response.choices[0]?.message?.content?.trim() || "[]";
    const cleaned = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const parsed = JSON.parse(cleaned) as any[];

    return parsed.map(seg => {
      const segPains = (seg.painProfile || []) as string[];
      const segDesires = (seg.desireProfile || []) as string[];
      const segObjections = (seg.objectionProfile || []) as string[];

      let painDesireMatchCount = 0;
      for (const p of segPains) {
        if (painMap.some(pm => pm.canonical.toLowerCase().includes(p.toLowerCase()))) painDesireMatchCount++;
      }
      for (const d of segDesires) {
        if (desireMap.some(dm => dm.canonical.toLowerCase().includes(d.toLowerCase()))) painDesireMatchCount++;
      }
      const totalProfileItems = segPains.length + segDesires.length;
      const signalCoverage = totalProfileItems > 0 ? Math.min(1, painDesireMatchCount / totalProfileItems) : 0;
      const painDesireDensity = Math.min(1, (painMap.length + desireMap.length) / 10);

      const allOtherSegments = parsed.filter((s: any) => s.name !== seg.name);
      let avgSim = 0;
      if (allOtherSegments.length > 0) {
        let simSum = 0;
        for (const other of allOtherSegments) {
          const overlap = [...segPains, ...segDesires].filter(
            t => [...(other.painProfile || []), ...(other.desireProfile || [])].some(
              (o: string) => o.toLowerCase() === t.toLowerCase()
            )
          ).length;
          const totalTokens = new Set([...segPains, ...segDesires, ...(other.painProfile || []), ...(other.desireProfile || [])]).size;
          simSum += totalTokens > 0 ? overlap / totalTokens : 0;
        }
        avgSim = simSum / allOtherSegments.length;
      }
      const segmentDistinctiveness = 1 - avgSim;

      const evidenceSupport = Math.min(1, (segObjections.length > 0 ? 0.5 : 0) + (segPains.length >= 2 ? 0.3 : 0.1) + (segDesires.length >= 2 ? 0.2 : 0.1));

      const segmentConfidence = Math.round(Math.min(0.95, Math.max(0.05,
        signalCoverage * 0.40 + painDesireDensity * 0.30 + segmentDistinctiveness * 0.20 + evidenceSupport * 0.10
      )) * 1000) / 1000;

      return {
        ...seg,
        evidenceCount: painMap.length + desireMap.length + objectionMap.length,
        confidenceScore: segmentConfidence,
        sourceSignals: ["painMap", "desireMap", "objectionMap", "emotionalDrivers"],
        inputSnapshotId,
      };
    });
  } catch (err: any) {
    console.error("[AudienceEngine-V3] Segment construction failed:", err.message);
    return [{
      name: "Primary Audience",
      description: "Main audience segment based on available data",
      painProfile: painMap.slice(0, 3).map(p => p.canonical),
      desireProfile: desireMap.slice(0, 3).map(d => d.canonical),
      objectionProfile: objectionMap.slice(0, 2).map(o => o.canonical),
      motivationProfile: emotionalDrivers.slice(0, 2).map(e => e.canonical),
      estimatedPercentage: 100,
      evidenceCount: painMap.length + desireMap.length,
      confidenceScore: 0.3,
      sourceSignals: ["painMap", "desireMap"],
      inputSnapshotId,
    }];
  }
}

const ADS_PRESCRIPTIVE_PATTERNS = [
  /\bset (?:your |the )?budget\b/i,
  /\ballocate \$?\d/i,
  /\bspend \$?\d/i,
  /\bdaily budget\b/i,
  /\blifetime budget\b/i,
  /\bcreate (?:a |an )?(?:ad set|campaign|ad group)\b/i,
  /\bgo to ads manager\b/i,
  /\bselect (?:conversion|traffic|reach) objective\b/i,
  /\bconfigure (?:the |your )?pixel\b/i,
  /\benable (?:CBO|ABO|advantage\+)\b/i,
  /\boptimize for (?:conversions|clicks|reach|impressions)\b/i,
  /\buse (?:automatic|manual) placements\b/i,
  /\bscale (?:the |your )?campaign\b/i,
  /\bincrease (?:the |your )?budget\b/i,
  /\ba\/b test (?:the |your )/i,
];

function sanitizeAdsTargetingHint(hint: AdsTargetingHint): AdsTargetingHint {
  if (hint.rationale) {
    for (const pattern of ADS_PRESCRIPTIVE_PATTERNS) {
      if (pattern.test(hint.rationale)) {
        hint.rationale = hint.rationale.replace(pattern, "[hint]").trim();
      }
    }
  }
  return hint;
}

async function translateToAdsTargeting(
  segments: AudienceSegment[],
  maturity: MaturityResult,
  businessContext: { industry: string; coreOffer: string; location: string },
  accountId: string,
  inputSnapshotId: string | null,
): Promise<AdsTargetingHint[]> {
  try {
    const prompt = `You are a Meta Ads targeting expert. Translate audience segments into Meta Ads Manager targeting suggestions.

BUSINESS: ${businessContext.industry} — ${businessContext.coreOffer}
LOCATION: ${businessContext.location || "Not specified"}
MARKET MATURITY: ${maturity.level}

SEGMENTS:
${segments.map(s => `- ${s.name}: Pains=${s.painProfile.join(", ")}. Desires=${s.desireProfile.join(", ")}. Objections=${s.objectionProfile.join(", ")}`).join("\n")}

For each segment, return:
{
  "suggestedInterests": ["real Meta interest categories"],
  "suggestedBehaviors": ["real Meta behavior targeting options"],
  "suggestedAgeRange": { "min": number, "max": number },
  "suggestedGender": "all" | "male" | "female",
  "suggestedLocations": ["country/region suggestions"],
  "rationale": "brief explanation"
}

Return ONLY a JSON array matching the segments count. Use real Meta Ads targeting options.`;

    const response = await aiChat({
      model: "gpt-4.1-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.3,
      max_tokens: 1500,
      endpoint: "audience-engine-v3-ads-targeting",
      accountId,
    });

    const content = response.choices[0]?.message?.content?.trim() || "[]";
    const cleaned = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const parsed = JSON.parse(cleaned) as any[];

    return parsed.map(hint => sanitizeAdsTargetingHint({
      ...hint,
      evidenceCount: segments.length,
      confidenceScore: 0.6,
      sourceSignals: ["audienceSegments", "maturityIndex"],
      inputSnapshotId,
    }));
  } catch (err: any) {
    console.error("[AudienceEngine-V3] Ads targeting failed:", err.message);
    return [{
      suggestedInterests: [businessContext.industry],
      suggestedBehaviors: ["Engaged shoppers"],
      suggestedAgeRange: { min: 18, max: 55 },
      suggestedGender: "all",
      suggestedLocations: [businessContext.location || "United States"],
      rationale: "Fallback targeting based on business context",
      evidenceCount: 0,
      confidenceScore: 0.2,
      sourceSignals: ["fallback"],
      inputSnapshotId,
    }];
  }
}

function buildStructuredSignals(
  painMap: SignalItem[],
  desireMap: SignalItem[],
  objectionMap: SignalItem[],
  transformationMap: SignalItem[],
  emotionalDrivers: SignalItem[],
  awarenessLevel: AwarenessResult,
  intentDistribution: IntentDistribution,
): StructuredSignals {
  const toCluster = (items: SignalItem[], layer: "surface" | "pattern" | "interpretation"): StructuredSignalCluster[] =>
    items.map((item, i) => ({
      id: `${layer}_${i}_${item.canonical.replace(/\s+/g, "_").toLowerCase().slice(0, 30)}`,
      label: item.canonical,
      frequency: item.frequency,
      confidence: item.confidenceScore,
      evidence: item.evidence.slice(0, 3),
      sourceLayer: layer,
    }));

  const pain_clusters = toCluster(painMap, "surface");
  const desire_clusters = toCluster(desireMap, "surface");

  const allFrequencyItems = [...painMap, ...desireMap, ...objectionMap].filter(s => s.frequency >= 2);
  const sortedByFreq = allFrequencyItems.sort((a, b) => b.frequency - a.frequency);
  const pattern_clusters = toCluster(sortedByFreq.slice(0, 10), "pattern");

  const rootCauseInputs: SignalItem[] = [];
  const highConfPains = painMap.filter(p => p.confidenceScore >= 0.4);
  const highConfObjections = objectionMap.filter(o => o.confidenceScore >= 0.3);

  for (const pain of highConfPains) {
    const relatedDriver = emotionalDrivers.find(d =>
      d.evidence.some(e => pain.evidence.some(pe => e.toLowerCase().includes(pe.toLowerCase().slice(0, 20)) || pe.toLowerCase().includes(e.toLowerCase().slice(0, 20))))
    );
    rootCauseInputs.push({
      ...pain,
      canonical: relatedDriver
        ? `${pain.canonical} driven by ${relatedDriver.canonical}`
        : `${pain.canonical} (recurring audience friction)`,
      confidenceScore: Math.min(0.95, pain.confidenceScore + (relatedDriver ? 0.1 : 0)),
    });
  }

  for (const obj of highConfObjections.slice(0, 3)) {
    if (!rootCauseInputs.some(r => r.canonical.toLowerCase().includes(obj.canonical.toLowerCase()))) {
      rootCauseInputs.push({
        ...obj,
        canonical: `Buying barrier: ${obj.canonical}`,
      });
    }
  }

  const root_causes = toCluster(
    rootCauseInputs.sort((a, b) => b.confidenceScore - a.confidenceScore).slice(0, 8),
    "interpretation",
  );

  const psychDriverInputs: SignalItem[] = emotionalDrivers.map(d => ({
    ...d,
    canonical: d.canonical,
  }));

  if (awarenessLevel.level !== "insufficient_signals") {
    psychDriverInputs.push({
      canonical: `Awareness state: ${awarenessLevel.level} — audience ${awarenessLevel.level === "unaware" ? "doesn't know the problem exists" : awarenessLevel.level === "problem_aware" ? "feels the pain but doesn't know solutions" : awarenessLevel.level === "solution_aware" ? "knows solutions exist but hasn't chosen" : "is evaluating specific products"}`,
      frequency: awarenessLevel.evidenceCount,
      evidence: [],
      evidenceCount: awarenessLevel.evidenceCount,
      confidenceScore: awarenessLevel.confidenceScore,
      sourceSignals: ["awareness"],
      inputSnapshotId: awarenessLevel.inputSnapshotId,
    });
  }

  if (intentDistribution.totalClassified > 0) {
    const dominantIntent = intentDistribution.purchaseIntent >= 30 ? "purchase-ready"
      : intentDistribution.comparison >= 30 ? "comparison-shopping"
      : intentDistribution.learning >= 30 ? "learning-phase"
      : "curiosity-stage";
    psychDriverInputs.push({
      canonical: `Dominant intent: ${dominantIntent} (${intentDistribution.totalClassified} signals classified)`,
      frequency: intentDistribution.totalClassified,
      evidence: [],
      evidenceCount: intentDistribution.totalClassified,
      confidenceScore: intentDistribution.confidenceScore,
      sourceSignals: ["intent"],
      inputSnapshotId: null,
    });
  }

  for (const t of transformationMap.slice(0, 3)) {
    psychDriverInputs.push({
      ...t,
      canonical: `Desired transformation: ${t.canonical}`,
    });
  }

  const psychological_drivers = toCluster(
    psychDriverInputs.sort((a, b) => b.confidenceScore - a.confidenceScore).slice(0, 8),
    "interpretation",
  );

  return { pain_clusters, desire_clusters, pattern_clusters, root_causes, psychological_drivers };
}

const EMPTY_STRUCTURED_SIGNALS: StructuredSignals = {
  pain_clusters: [],
  desire_clusters: [],
  pattern_clusters: [],
  root_causes: [],
  psychological_drivers: [],
};

function buildEmptyResult(
  status: EngineStatus,
  statusMessage: string,
  inputSummary: AudienceEngineV3Result["inputSummary"],
  executionTimeMs: number,
  snapshotId: string,
): AudienceEngineV3Result {
  const emptyMeta: EvidenceMeta = { evidenceCount: 0, confidenceScore: 0, sourceSignals: [], inputSnapshotId: inputSummary.miSnapshotId };
  return {
    status,
    statusMessage,
    defensiveMode: status === "DEFENSIVE_MODE",
    languageSignals: { ...emptyMeta, problemExpressions: { count: 0, samples: [] }, questionPatterns: { count: 0, samples: [] }, goalExpressions: { count: 0, samples: [] }, totalAnalyzed: 0 },
    painMap: [],
    desireMap: [],
    objectionMap: [],
    transformationMap: [],
    emotionalDrivers: [],
    audienceSegments: [],
    segmentDensity: [],
    awarenessLevel: { ...emptyMeta, level: "insufficient_signals", distribution: {} },
    maturityIndex: { ...emptyMeta, level: "insufficient_signals", distribution: {}, indicators: [] },
    intentDistribution: { ...emptyMeta, curiosity: 0, learning: 0, comparison: 0, purchaseIntent: 0, totalClassified: 0 },
    adsTargetingHints: [],
    structuredSignals: EMPTY_STRUCTURED_SIGNALS,
    inputSummary,
    engineVersion: AUDIENCE_ENGINE_VERSION,
    executionTimeMs,
    snapshotId,
  };
}

export async function runAudienceEngine(accountId: string, campaignId: string, miSnapshotIdParam?: string, jobId?: string): Promise<AudienceEngineV3Result> {
  const startTime = Date.now();
  console.log(`[AudienceEngine-V3] Starting analysis for account=${accountId} campaign=${campaignId}${miSnapshotIdParam ? ` | run-scoped MI=${miSnapshotIdParam}` : " | unscoped (will resolve latest)"}`);

  let latestSnapshot: any = null;
  if (miSnapshotIdParam) {
    const [byId] = await db.select().from(miSnapshots)
      .where(and(
        eq(miSnapshots.id, miSnapshotIdParam),
        eq(miSnapshots.accountId, accountId),
        eq(miSnapshots.campaignId, campaignId),
      ))
      .limit(1);
    latestSnapshot = byId || null;
    if (!latestSnapshot) {
      console.log(`[AudienceEngine-V3] RUN_SCOPED_MI_NOT_FOUND | id=${miSnapshotIdParam} — failing fast (no latest fallback in scoped mode)`);
      const executionTimeMs = Date.now() - startTime;
      return buildEmptyResult(
        "MISSING_DEPENDENCY",
        `Run-scoped MI snapshot ${miSnapshotIdParam} not found for campaign ${campaignId}`,
        { postsAnalyzed: 0, commentsAnalyzed: 0, competitorsAnalyzed: 0, sanitizedCount: 0, miSnapshotId: miSnapshotIdParam, miSnapshotAge: null },
        executionTimeMs,
        "",
      );
    }
  } else {
    const [byLatest] = await db.select().from(miSnapshots)
      .where(and(
        eq(miSnapshots.accountId, accountId),
        eq(miSnapshots.campaignId, campaignId),
        inArray(miSnapshots.status, ["COMPLETE", "PARTIAL"]),
      ))
      .orderBy(desc(miSnapshots.createdAt))
      .limit(1);
    latestSnapshot = byLatest || null;
  }

  const miSnapshotId = latestSnapshot?.id || null;
  const miSnapshotAge = latestSnapshot?.createdAt
    ? `${Math.round((Date.now() - new Date(latestSnapshot.createdAt).getTime()) / 3600000)}h ago`
    : null;
  let miFreshnessMetadata: import("../shared/snapshot-trust").FreshnessMetadata | null = null;
  if (latestSnapshot) {
    const { logFreshnessTraceability, buildFreshnessMetadata } = await import("../shared/snapshot-trust");
    miFreshnessMetadata = buildFreshnessMetadata(latestSnapshot);
    logFreshnessTraceability("AudienceEngine", latestSnapshot, miFreshnessMetadata);

    if (miFreshnessMetadata.blockedForStrategy) {
      console.log(`[AudienceEngine-V3] MI freshness BLOCKED | class=${miFreshnessMetadata.freshnessClass} | age=${miFreshnessMetadata.ageInDays}d | trust=${miFreshnessMetadata.trustScore} | schema=${miFreshnessMetadata.schemaRecommendation}`);
      const executionTimeMs = Date.now() - startTime;
      return buildEmptyResult(
        "MISSING_DEPENDENCY",
        miFreshnessMetadata.warning || `MI data freshness check failed (${miFreshnessMetadata.freshnessClass}). Re-run Market Intelligence before audience analysis.`,
        { postsAnalyzed: 0, commentsAnalyzed: 0, competitorsAnalyzed: 0, sanitizedCount: 0, miSnapshotId: miSnapshotId, miSnapshotAge: miSnapshotAge },
        executionTimeMs,
        "",
      );
    }
  }
  if (latestSnapshot && latestSnapshot.analysisVersion !== undefined) {
    const { ENGINE_VERSION: MI_EV } = await import("../market-intelligence-v3/constants");
    if (latestSnapshot.analysisVersion !== MI_EV) {
      console.log(`[AudienceEngine-V3] MI snapshot version mismatch: got v${latestSnapshot.analysisVersion}, expected v${MI_EV} — results may use stale MI data`);
    }
  }

  const competitors = await db.select().from(ciCompetitors)
    .where(and(
      eq(ciCompetitors.accountId, accountId),
      eq(ciCompetitors.campaignId, campaignId),
      eq(ciCompetitors.isActive, true),
    ));

  const enrichedCount = competitors.filter(c => c.enrichmentStatus === "ENRICHED").length;
  const pendingCount = competitors.filter(c => c.enrichmentStatus === "PENDING" || !c.enrichmentStatus).length;
  if (competitors.length > 0) {
    console.log(`[AudienceEngine-V3] INVENTORY_STATUS | total=${competitors.length} | enriched=${enrichedCount} | pending=${pendingCount}`);
  }

  const competitorIds = competitors.map(c => c.id);
  const competitorCount = competitorIds.length;

  let posts: { caption: string | null; platform: string }[] = [];
  let rawComments: { commentText: string | null }[] = [];
  let rawReviews: { reviewText: string }[] = [];

  if (competitorIds.length > 0) {
    const idList = sql.join(competitorIds.map(id => sql`${id}`), sql`, `);

    [posts, rawComments, rawReviews] = await Promise.all([
      db.select({ caption: ciCompetitorPosts.caption, platform: ciCompetitorPosts.platform })
        .from(ciCompetitorPosts)
        .where(sql`${ciCompetitorPosts.competitorId} IN (${idList})`)
        .orderBy(desc(ciCompetitorPosts.createdAt))
        .limit(AUDIENCE_THRESHOLDS.MAX_POSTS_TO_ANALYZE),

      db.select({ commentText: ciCompetitorComments.commentText })
        .from(ciCompetitorComments)
        .where(sql`${ciCompetitorComments.competitorId} IN (${idList}) AND (${ciCompetitorComments.isSynthetic} = false OR ${ciCompetitorComments.isSynthetic} IS NULL)`)
        .orderBy(desc(ciCompetitorComments.createdAt))
        .limit(AUDIENCE_THRESHOLDS.MAX_COMMENTS_TO_ANALYZE),

      db.select({ reviewText: ciCompetitorReviews.reviewText })
        .from(ciCompetitorReviews)
        .where(sql`${ciCompetitorReviews.competitorId} IN (${idList}) AND ${ciCompetitorReviews.isSynthetic} = false`)
        .orderBy(desc(ciCompetitorReviews.createdAt))
        .limit(300),
    ]);
  }

  const instagramPosts = posts.filter(p => !p.platform || p.platform === "instagram");
  const tiktokPosts = posts.filter(p => p.platform === "tiktok");

  const rawCaptions = instagramPosts.map(p => p.caption).filter((c): c is string => !!c && c.length > 5);
  const rawTiktokTexts = tiktokPosts.map(p => p.caption).filter((c): c is string => !!c && c.length > 5);
  const rawCommentTexts = rawComments.map(c => c.commentText).filter((c): c is string => !!c && c.length > 3);
  const rawReviewTexts = rawReviews.map(r => r.reviewText).filter(t => t.length > 5);

  const captionSanitized = sanitizeTexts(rawCaptions);
  const commentSanitized = sanitizeTexts(rawCommentTexts);
  const captions = captionSanitized.clean;
  const commentTexts = commentSanitized.clean;
  const totalSanitized = captionSanitized.removed + commentSanitized.removed;

  const commentClassification = buildLabeledComments(commentTexts);
  const labeledComments = commentClassification.labeled;
  const labeledCaptions = buildLabeledCaptions(captions);
  const labeledReviews = buildLabeledReviews(rawReviewTexts);
  const labeledTiktok = buildLabeledTiktok(rawTiktokTexts);
  const labeledAllTexts: LabeledText[] = [...labeledComments, ...labeledCaptions, ...labeledReviews, ...labeledTiktok];
  const primaryDataStrength = computePrimaryDataStrength(labeledComments, labeledCaptions);

  console.log(
    `[AudienceEngine-V3] Data: ${competitorCount} competitors, ${captions.length} captions, ${commentTexts.length} comments` +
    ` | reviews=${labeledReviews.length} tiktok=${labeledTiktok.length}` +
    ` (sanitized ${totalSanitized} synthetic | noise-filtered ${commentClassification.noiseCount}` +
    ` | HIGH=${commentClassification.highCount} MED=${commentClassification.mediumCount} LOW=${commentClassification.lowCount})` +
    ` | primaryStrength=${primaryDataStrength.toFixed(3)}`
  );

  const baseInputSummary = {
    postsAnalyzed: captions.length,
    commentsAnalyzed: commentTexts.length,
    competitorsAnalyzed: competitorCount,
    sanitizedCount: totalSanitized,
    reviewsAnalyzed: labeledReviews.length,
    tiktokAnalyzed: labeledTiktok.length,
    commentQuality: {
      noise: commentClassification.noiseCount,
      low: commentClassification.lowCount,
      medium: commentClassification.mediumCount,
      high: commentClassification.highCount,
    },
    primaryDataStrength,
    miSnapshotId,
    miSnapshotAge,
    detectedMarkets: [] as string[],
  };

  const datasetTooSmall =
    competitorCount < AUDIENCE_THRESHOLDS.MIN_COMPETITORS_FOR_ANALYSIS ||
    captions.length < AUDIENCE_THRESHOLDS.MIN_POSTS_FOR_ANALYSIS;

  let bridgeResult: SemanticBridgeResult | null = null;
  if (latestSnapshot) {
    if (!datasetTooSmall && primaryDataStrength >= BRIDGE_SUPPRESS_THRESHOLD) {
      console.log(
        `[AudienceEngine-V3] BRIDGE_SUPPRESSED | primaryStrength=${primaryDataStrength.toFixed(3)} >= threshold=${BRIDGE_SUPPRESS_THRESHOLD} | primary data is sufficient`
      );
    } else {
      bridgeResult = executeSemanticBridge(latestSnapshot);
      const bridgeValidation = validateBridgeIntegrity(bridgeResult);
      if (!bridgeValidation.valid) {
        console.log(`[AudienceEngine-V3] SEMANTIC_BRIDGE_VALIDATION_FAIL | issues=${bridgeValidation.issues.join("; ")}`);
        bridgeResult = null;
      } else {
        console.log(`[AudienceEngine-V3] SEMANTIC_BRIDGE_ACTIVE | pains=${bridgeResult.painSignals.length} | desires=${bridgeResult.desireSignals.length} | objections=${bridgeResult.objectionSignals.length} | integrity=${bridgeResult.bridgeIntegrity} | reason=${datasetTooSmall ? "dataset_too_small" : "primary_weak"}`);
      }
    }
  }

  const bridgeCanRescue = bridgeResult && bridgeResult.bridgeIntegrity && bridgeResult.totalPassed >= AUDIENCE_THRESHOLDS.MIN_SIGNAL_MATCHES_FOR_AI;

  if (datasetTooSmall) {
    if (bridgeCanRescue) {
      console.log(`[AudienceEngine-V3] DATASET_TOO_SMALL bypassed — Semantic Bridge provides ${bridgeResult!.totalPassed} quality-gated signals from MIv3 contentDnaData (bridge-only mode)`);
    } else {
      const msg = `DATASET TOO SMALL FOR RELIABLE AUDIENCE INTELLIGENCE — Need ≥${AUDIENCE_THRESHOLDS.MIN_COMPETITORS_FOR_ANALYSIS} competitors (have ${competitorCount}), ≥${AUDIENCE_THRESHOLDS.MIN_POSTS_FOR_ANALYSIS} posts (have ${captions.length}), comments available: ${commentTexts.length}${latestSnapshot ? `, bridge signals: ${bridgeResult?.totalPassed || 0}` : ", no MI snapshot"}`;
      console.log(`[AudienceEngine-V3] ${msg}`);

      const executionTimeMs = Date.now() - startTime;
      const [inserted] = await db.insert(audienceSnapshots).values({
        accountId, campaignId, jobId, miSnapshotId,
        engineVersion: AUDIENCE_ENGINE_VERSION,
        inputSummary: JSON.stringify({ ...baseInputSummary, status: "DATASET_TOO_SMALL", statusMessage: msg }),
        executionTimeMs,
      }).returning({ id: audienceSnapshots.id });

      await pruneOldSnapshots(db, audienceSnapshots, campaignId, 20, accountId);

      const emptyResult = buildEmptyResult("DATASET_TOO_SMALL", msg, baseInputSummary, executionTimeMs, inserted.id);
      return { ...emptyResult, freshnessMetadata: miFreshnessMetadata };
    }
  }

  if (commentTexts.length === 0) {
    console.log(`[AudienceEngine-V3] NO_COMMENT_TEXT — proceeding with ${captions.length} captions${bridgeCanRescue ? " + semantic bridge signals" : " only"}`);
  }

  const [campaign] = await db.select().from(growthCampaigns)
    .where(eq(growthCampaigns.id, campaignId))
    .limit(1);

  const productDna = await loadProductDNA(campaignId, accountId);
  const businessContext = {
    industry: productDna?.businessType || productDna?.productCategory || campaign?.name || "General",
    coreOffer: productDna?.coreOffer || campaign?.name || "Products/Services",
    targetAudience: productDna?.targetDecisionMaker || productDna?.targetAudienceSegment || "Market audience",
    location: "",
    productDna: productDna || undefined,
  };
  if (productDna) {
    console.log(`[AudienceEngine-V3] PRODUCT_DNA_LOADED | category=${productDna.productCategory || "n/a"} | mechanism=${productDna.uniqueMechanism || "n/a"} | advantage=${productDna.strategicAdvantage || "n/a"}`);
  }

  const allText = [...commentTexts, ...captions];

  const { markets: detectedMarkets, metadata: scopeMetadata } = detectMarketScope(allText, businessContext);
  baseInputSummary.detectedMarkets = detectedMarkets;
  console.log(`[AudienceEngine-V3] Market scope detected: ${detectedMarkets.join(", ")} | scopeConfidence=${scopeMetadata.scopeConfidence} | ambiguity=${scopeMetadata.scopeAmbiguityFlag}`);

  const scopedPainClusters = filterClustersByMarket(PAIN_CLUSTERS, detectedMarkets);
  const scopedDesireClusters = filterClustersByMarket(DESIRE_CLUSTERS, detectedMarkets);
  const scopedObjectionClusters = filterClustersByMarket(OBJECTION_CLUSTERS, detectedMarkets);

  const languageSignals = analyzeLanguage(commentTexts, captions, miSnapshotId, competitorCount, rawReviewTexts, rawTiktokTexts);
  const rawPainMap = matchPatternClusters(labeledAllTexts, scopedPainClusters, miSnapshotId, competitorCount);
  const rawDesireMap = matchPatternClusters(labeledAllTexts, scopedDesireClusters, miSnapshotId, competitorCount);
  let rawObjectionMap = matchPatternClusters(labeledAllTexts, scopedObjectionClusters, miSnapshotId, competitorCount);
  const rawTransformationMap = matchPatternClusters(labeledAllTexts, TRANSFORMATION_PATTERNS, miSnapshotId, competitorCount);
  const rawEmotionalDrivers = matchPatternClusters(labeledAllTexts, EMOTIONAL_DRIVER_PATTERNS, miSnapshotId, competitorCount);

  rawObjectionMap = applyObjectionContextRules(rawObjectionMap, allText);

  let directPainMap = applyEvidenceIntegrityFilter(rawPainMap);
  let desireMap = applyEvidenceIntegrityFilter(rawDesireMap);
  let objectionMap = applyEvidenceIntegrityFilter(rawObjectionMap);
  const transformationMap = applyEvidenceIntegrityFilter(rawTransformationMap);
  const emotionalDrivers = applyEvidenceIntegrityFilter(rawEmotionalDrivers);

  const narrativeObjectionSignals = buildNarrativeObjectionSignals(latestSnapshot, miSnapshotId);
  if (narrativeObjectionSignals.length > 0) {
    const narrMerge = mergeNarrativeObjectionsIntoMap(objectionMap, narrativeObjectionSignals);
    objectionMap = narrMerge.merged;
    console.log(`[AudienceEngine-V3] NARRATIVE_OBJECTIONS_MERGED | ingested=${narrativeObjectionSignals.length} | added=${narrMerge.added} | reinforced=${narrMerge.reinforced} | total=${objectionMap.length}`);
  }

  let bridgePainSignals: SignalItem[] = [];
  let totalBridgeConflicts = 0;
  if (bridgeResult && bridgeResult.bridgeIntegrity) {
    const painMerge = mergeBridgedIntoAudienceMap(directPainMap, bridgeResult.painSignals, miSnapshotId);
    directPainMap = painMerge.merged;
    bridgePainSignals = bridgeResult.painSignals.map((bs: any) => ({
      canonical: bs.canonical,
      frequency: bs.frequency || 1,
      evidence: bs.evidence || [],
      evidenceCount: bs.evidenceCount || 1,
      // no 0.1 floor and no 0.3 phantom-default. A bridge signal that
      // carries no confidence emits zero; downstream gates decide whether to
      // surface it or drop it.
      confidenceScore: (typeof bs.confidenceScore === "number" ? bs.confidenceScore : 0) * 0.7,
      sourceSignals: [...(bs.sourceSignals || []), "bridge_signal"],
      inputSnapshotId: miSnapshotId,
    }));
    totalBridgeConflicts += painMerge.conflictsResolved;

    const desireMerge = mergeBridgedIntoAudienceMap(desireMap, bridgeResult.desireSignals, miSnapshotId);
    desireMap = desireMerge.merged;
    totalBridgeConflicts += desireMerge.conflictsResolved;

    const objectionMerge = mergeBridgedIntoAudienceMap(objectionMap, bridgeResult.objectionSignals, miSnapshotId);
    objectionMap = objectionMerge.merged;
    totalBridgeConflicts += objectionMerge.conflictsResolved;

    if (totalBridgeConflicts > 0) {
      console.log(`[AudienceEngine-V3] CONFLICT_RESOLUTION | conflictsResolved=${totalBridgeConflicts} | anchor=MIv3_QUALITY_GATED`);
    }
    console.log(`[AudienceEngine-V3] SEMANTIC_BRIDGE_MERGED | pains=${directPainMap.length} | desires=${desireMap.length} | objections=${objectionMap.length}`);
  }

  const qualifiedObjections = objectionMap.filter(o => o.confidenceScore >= 0.25 && o.evidenceCount >= 1);
  const qualifiedDrivers = emotionalDrivers.filter(d => d.confidenceScore >= 0.25 && d.evidenceCount >= 1);
  const objectionInferredPains = inferPainsFromObjections(qualifiedObjections, miSnapshotId).slice(0, 5);
  const driverInferredPains = inferPainsFromEmotionalDrivers(qualifiedDrivers, miSnapshotId).slice(0, 3);
  const { finalPainMap, painSources } = mergePainLayers(directPainMap, objectionInferredPains, driverInferredPains, bridgePainSignals);
  let painMap = finalPainMap;
  console.log(`[AudienceEngine-V3] PAIN_LAYERED_CONSTRUCTION | direct=${painSources.direct} | objectionInferred=${painSources.objectionInferred} | driverInferred=${painSources.driverInferred} | bridge=${painSources.bridge} | final=${painMap.length}`);

  let miObjectionDensity = 0;
  let miObjectionCount = 0;
  if (latestSnapshot?.objectionMapData) {
    try {
      const miObjMap = JSON.parse(latestSnapshot.objectionMapData);
      miObjectionDensity = miObjMap?.objectionDensity || 0;
      miObjectionCount = miObjMap?.totalObjectionsDetected || 0;
      if (miObjectionCount > 0) {
        console.log(`[AudienceEngine-V3] MI_NARRATIVE_OBJECTIONS | count=${miObjectionCount} | density=${miObjectionDensity} | multiCompetitor=${miObjMap?.objectionsFromMultipleCompetitors || 0}`);
      }
    } catch {}
  }

  const awarenessInput = commentTexts.length > 0 ? commentTexts : captions;
  const awarenessLevel = detectAwareness(awarenessInput, miSnapshotId, competitorCount, miObjectionDensity, miObjectionCount);
  const maturityIndex = detectMaturity(commentTexts, captions, miSnapshotId, competitorCount);
  const intentInput = commentTexts.length > 0 ? commentTexts : captions;
  const intentDistribution = classifyIntents(intentInput, miSnapshotId, competitorCount);
  const intentTemperature = deriveIntentTemperature(intentDistribution);
  console.log(`[AudienceEngine-V3] Intent temperature: ${intentTemperature} (curiosity=${intentDistribution.curiosity}% learning=${intentDistribution.learning}% comparison=${intentDistribution.comparison}% purchase=${intentDistribution.purchaseIntent}%)`);

  const totalSignalMatches = painMap.length + desireMap.length + objectionMap.length + transformationMap.length + emotionalDrivers.length;
  const totalSignalFrequency = [painMap, desireMap, objectionMap, transformationMap, emotionalDrivers]
    .flat().reduce((sum, s) => sum + s.frequency, 0);

  const dataReliability = sharedAssessDataReliability(
    competitorCount,
    totalSignalMatches,
    false,
    false,
    true,
    0.5,
  );
  if (dataReliability.isWeak) {
    console.log(`[AudienceEngine-V3] DATA_RELIABILITY_WEAK | reliability=${dataReliability.overallReliability.toFixed(3)} | advisories=${dataReliability.advisories.join("; ")}`);
  }

  const genericCheck = detectGenericOutput(allText.join(" ").substring(0, 2000));
  if (genericCheck.genericDetected) {
    console.log(`[AudienceEngine-V3] GENERIC_OUTPUT_DETECTED | penalty=${genericCheck.penalty.toFixed(3)} | matches=${genericCheck.genericPhrases.join(", ")}`);
  }

  const isDefensiveMode = totalSignalFrequency < AUDIENCE_THRESHOLDS.DEFENSIVE_MODE_SIGNAL_THRESHOLD;

  let audienceSegments: AudienceSegment[] = [];
  let adsTargetingHints: AdsTargetingHint[] = [];

  if (totalSignalMatches < AUDIENCE_THRESHOLDS.MIN_SIGNAL_MATCHES_FOR_AI) {
    console.log(`[AudienceEngine-V3] INSUFFICIENT SIGNALS for AI layers — ${totalSignalMatches} signal matches (need ≥${AUDIENCE_THRESHOLDS.MIN_SIGNAL_MATCHES_FOR_AI})`);
  } else if (isDefensiveMode) {
    console.log(`[AudienceEngine-V3] DEFENSIVE MODE — signal density too low (${totalSignalFrequency} total frequency), skipping AI layers`);
  } else {
    const rawSegments = await constructSegments(
      painMap, desireMap, objectionMap, emotionalDrivers,
      maturityIndex, awarenessLevel,
      businessContext, commentTexts, accountId, miSnapshotId,
    );

    audienceSegments = canonicalizeSegments(rawSegments);
    console.log(`[AudienceEngine-V3] Canonicalization: ${rawSegments.length} raw → ${audienceSegments.length} canonical segments`);

    adsTargetingHints = await translateToAdsTargeting(
      audienceSegments, maturityIndex, businessContext, accountId, miSnapshotId,
    );
  }

  // ── INTELLIGENCE UPGRADE: Sophistication Tier Scoring (Schwartz tradition) ──
  let audienceSophistication: AudienceSophisticationOutput | null = null;
  if (audienceSegments.length > 0) {
    try {
      const competitorClaimsForSophistication: string[] = [];
      try {
        const latestMi = await db
          .select({ marketDiagnosis: miSnapshots.marketDiagnosis, opportunitySignals: miSnapshots.opportunitySignals })
          .from(miSnapshots)
          .where(eq(miSnapshots.id, miSnapshotId || ""))
          .limit(1);
        if (latestMi[0]) {
          const opps = JSON.parse((latestMi[0].opportunitySignals as any) || "[]");
          for (const o of opps.slice(0, 8)) {
            const c = typeof o === "string" ? o : (o.signal || o.text || o.claim || "");
            if (c) competitorClaimsForSophistication.push(c);
          }
        }
      } catch { /* ignore */ }

      audienceSophistication = await scoreAudienceSophistication({
        industry: businessContext.industry,
        coreOffer: businessContext.coreOffer,
        segments: audienceSegments.map(s => ({
          name: s.name,
          description: (s as any).description,
          painProfile: s.painProfile || [],
          desireProfile: s.desireProfile || [],
          objectionProfile: s.objectionProfile || [],
        })),
        comments: commentTexts,
        objections: objectionMap.slice(0, 12).map(o => o.canonical),
        marketDiagnosis: null,
        competitorClaims: competitorClaimsForSophistication,
        accountId,
      });

      if (audienceSophistication) {
        for (const segment of audienceSegments) {
          const profile = audienceSophistication.segments.find(p =>
            p.segmentName.toLowerCase().trim() === segment.name.toLowerCase().trim(),
          );
          if (profile) {
            (segment as any).sophisticationProfile = profile;
          }
        }
        console.log(`[AudienceEngine-V3] SOPHISTICATION_ATTACHED | globalTier=${audienceSophistication.globalTier} | segmentsScored=${audienceSophistication.segments.length}/${audienceSegments.length} | burnt=${audienceSophistication.marketIsBurnt}`);
      }
    } catch (sophErr: any) {
      console.error(`[AudienceEngine-V3] SOPHISTICATION_FAILED | ${sophErr.message}`);
    }
  }

  // ── PHASE 4 MARKETING-LOGIC UPGRADE: Buyer Psychology Profiler ──
  // Reasons about belief model + rejection history + decision trigger + identity aspiration
  // for the highest-density segment. Sophistication tier becomes a byproduct of belief-model
  // maturity, not the primary output. Cialdini leverages are psychology-matched, not category-default.
  let buyerPsychologyProfile: import("./buyer-psychology").BuyerPsychologyProfile | null = null;
  if (totalSignalMatches >= AUDIENCE_THRESHOLDS.MIN_SIGNAL_MATCHES_FOR_AI && audienceSegments.length > 0) {
    try {
      const { profileBuyerPsychology } = await import("./buyer-psychology");
      const targetSegment: any = audienceSegments[0];
      const rejectedClaimPatterns: string[] = [];
      const segProfile = (targetSegment as any)?.sophisticationProfile;
      if (segProfile?.rejectedClaimPatterns) {
        for (const p of segProfile.rejectedClaimPatterns) rejectedClaimPatterns.push(p.pattern);
      }
      const competitorClaimsForPsych: string[] = [];
      try {
        const latestMi2 = await db.select()
          .from(miSnapshots)
          .where(eq(miSnapshots.id, miSnapshotId || ""))
          .limit(1);
        if (latestMi2[0]) {
          const opps = JSON.parse((latestMi2[0].opportunitySignals as any) || "[]");
          for (const o of opps.slice(0, 8)) {
            const c = typeof o === "string" ? o : (o.signal || o.text || o.claim || "");
            if (c) competitorClaimsForPsych.push(c);
          }
        }
      } catch { /* ignore */ }

      buyerPsychologyProfile = await profileBuyerPsychology({
        segmentName: targetSegment.name || "Primary Segment",
        segmentDescription: (targetSegment as any).description || "",
        audiencePains: painMap.slice(0, 8).map(p => p.canonical),
        audienceDesires: desireMap.slice(0, 8).map(d => d.canonical),
        audienceObjections: objectionMap.slice(0, 8).map(o => o.canonical),
        buyerComments: commentTexts.slice(0, 8),
        competitorClaims: competitorClaimsForPsych,
        rejectedClaimPatterns,
        industry: businessContext.industry || "",
        coreOffer: businessContext.coreOffer || "",
        accountId,
      });
      if (buyerPsychologyProfile) {
        console.log(`[AudienceEngine-V3] BUYER_PSYCHOLOGY_ATTACHED | tier=${buyerPsychologyProfile.sophisticationByproduct.tier} | aspirational="${buyerPsychologyProfile.identityAspiration.aspirationalIdentity.slice(0, 50)}" | leverages=[${buyerPsychologyProfile.cialdiniLeverages.join(",")}] | retries=${buyerPsychologyProfile.retryCount}`);
      } else {
        console.log(`[AudienceEngine-V3] BUYER_PSYCHOLOGY_FALLBACK | profiler returned null — engine continuing with legacy output`);
      }
    } catch (psychErr: any) {
      console.error(`[AudienceEngine-V3] BUYER_PSYCHOLOGY_FAILED | ${psychErr.message} — engine continuing with legacy output`);
    }
  }

  const segmentDensity = computeSegmentDensity(painMap, desireMap, audienceSegments, miSnapshotId);

  const executionTimeMs = Date.now() - startTime;

  let status: EngineStatus = "COMPLETE";
  let statusMessage: string | null = null;

  if (totalSignalMatches < AUDIENCE_THRESHOLDS.MIN_SIGNAL_MATCHES_FOR_AI) {
    status = "INSUFFICIENT_SIGNALS";
    statusMessage = "INSUFFICIENT DATA FOR RELIABLE AUDIENCE INTELLIGENCE — AI layers skipped due to weak signal coverage";
  } else if (awarenessLevel?.level === "insufficient_signals" && intentDistribution?.totalClassified === 0) {
    status = "INSUFFICIENT_SIGNALS";
    statusMessage = "Key classifiers returned insufficient signals — awareness and intent data unreliable";
  } else if (isDefensiveMode) {
    status = "DEFENSIVE_MODE";
    statusMessage = "Low signal environment detected — Audience intelligence limited — More market data required";
  } else {
    // PARTIAL emission: engine produced usable
    // output but coverage is incomplete. Triggers when (a) signals are above
    // the AI floor but below the doubled "rich coverage" mark, OR (b) any of
    // the core maps came back empty, OR (c) no audience segments resolved.
    // Snapshot-reuse + System Control read this status verbatim.
    const richSignalFloor = AUDIENCE_THRESHOLDS.MIN_SIGNAL_MATCHES_FOR_AI * 2;
    const coreMaps = [painMap, desireMap, objectionMap];
    const anyEmpty = coreMaps.some((m) => !Array.isArray(m) || m.length === 0);
    if (totalSignalMatches < richSignalFloor || anyEmpty || (audienceSegments?.length ?? 0) === 0) {
      status = "PARTIAL";
      const reasons: string[] = [];
      if (totalSignalMatches < richSignalFloor) reasons.push(`signals=${totalSignalMatches}<${richSignalFloor}`);
      if (anyEmpty) reasons.push("core_map_empty");
      if ((audienceSegments?.length ?? 0) === 0) reasons.push("no_segments");
      statusMessage = `PARTIAL audience output — coverage incomplete (${reasons.join("; ")}); downstream engines must treat as low-confidence`;
    }
  }

  const inputSummary = {
    ...baseInputSummary,
    ...(bridgeResult ? {
      semanticBridge: {
        totalIngested: bridgeResult.totalIngested,
        totalPassed: bridgeResult.totalPassed,
        conflictsResolved: totalBridgeConflicts,
        bridgeIntegrity: bridgeResult.bridgeIntegrity,
        cleanPipeEnforced: bridgeResult.cleanPipeEnforced,
      },
    } : {}),
  };

  const audienceLineage: SignalLineageEntry[] = [];
  painMap.forEach((p: any, i: number) => {
    if (p.canonical) audienceLineage.push(createSourceLineageEntry("audience", "audience_pain", p.canonical, i, "competitor"));
  });
  desireMap.forEach((d: any, i: number) => {
    if (d.canonical) audienceLineage.push(createSourceLineageEntry("audience", "audience_desire", d.canonical, i, "competitor"));
  });
  objectionMap.forEach((o: any, i: number) => {
    if (o.canonical) audienceLineage.push(createSourceLineageEntry("audience", "audience_objection", o.canonical, i, "competitor"));
  });
  (emotionalDrivers || []).forEach((d: any, i: number) => {
    const text = typeof d === "string" ? d : (d?.driver || d?.description || d?.canonical || "");
    if (text) audienceLineage.push(createSourceLineageEntry("audience", "emotional_driver", text, i, "competitor"));
  });
  if (bridgeResult && bridgeResult.bridgeIntegrity) {
    const allBridgedSignals = [...bridgeResult.painSignals, ...bridgeResult.desireSignals, ...bridgeResult.objectionSignals];
    allBridgedSignals.forEach((bs, i) => {
      audienceLineage.push(createSourceLineageEntry(
        "audience",
        `bridge_${bs.category}_${bs.bridgeSource}`,
        `${bs.canonical} [parent:${bs.parentSignalId}]`,
        i,
        "competitor",
      ));
    });
  }
  console.log(`[AudienceEngine-V3] LINEAGE_GENERATED | entries=${audienceLineage.length} | pains=${painMap.length} | desires=${desireMap.length} | objections=${objectionMap.length} | bridged=${bridgeResult?.totalPassed || 0}`);

  const structuredSignals = buildStructuredSignals(
    painMap, desireMap, objectionMap, transformationMap, emotionalDrivers,
    awarenessLevel, intentDistribution,
  );
  console.log(`[AudienceEngine-V3] STRUCTURED_SIGNALS | pains=${structuredSignals.pain_clusters.length} | desires=${structuredSignals.desire_clusters.length} | patterns=${structuredSignals.pattern_clusters.length} | rootCauses=${structuredSignals.root_causes.length} | psychDrivers=${structuredSignals.psychological_drivers.length}`);

  const [inserted] = await db.insert(audienceSnapshots).values({
    accountId, campaignId, jobId, miSnapshotId,
    engineVersion: AUDIENCE_ENGINE_VERSION,
    languageSignals: JSON.stringify(languageSignals),
    audiencePains: JSON.stringify(painMap),
    desireMap: JSON.stringify(desireMap),
    objectionMap: JSON.stringify(objectionMap),
    transformationMap: JSON.stringify(transformationMap),
    emotionalDrivers: JSON.stringify(emotionalDrivers),
    audienceSegments: JSON.stringify(audienceSegments),
    segmentDensity: JSON.stringify(segmentDensity),
    awarenessLevel: JSON.stringify(awarenessLevel),
    maturityIndex: JSON.stringify(maturityIndex),
    audienceIntentDistribution: JSON.stringify(intentDistribution),
    adsTargetingHints: JSON.stringify(adsTargetingHints),
    inputSummary: JSON.stringify(inputSummary),
    signalLineage: JSON.stringify(audienceLineage),
    structuredSignals: JSON.stringify(structuredSignals),
    executionTimeMs,
  }).returning({ id: audienceSnapshots.id });

  await pruneOldSnapshots(db, audienceSnapshots, campaignId, 20, accountId);

  try {
    const { invalidateDownstreamOnRegeneration } = await import("../shared/strategy-root");
    const inv = await invalidateDownstreamOnRegeneration(campaignId, accountId, "audience");
    if (inv.supersededRoots > 0) {
      console.log(`[AudienceEngine-V3] ROOT_INVALIDATED | superseded=${inv.supersededRoots}`);
    }
  } catch (invErr: any) {
    console.error(`[AudienceEngine-V3] Root invalidation failed (non-blocking): ${invErr.message}`);
  }

  console.log(`[AudienceEngine-V3] ${status} in ${executionTimeMs}ms | snapshot=${inserted.id} | signals=${totalSignalMatches} | freq=${totalSignalFrequency} | segments=${audienceSegments.length} | defensive=${isDefensiveMode}`);

  return {
    status,
    statusMessage,
    defensiveMode: isDefensiveMode,
    languageSignals,
    painMap,
    desireMap,
    objectionMap,
    transformationMap,
    emotionalDrivers,
    audienceSegments,
    segmentDensity,
    awarenessLevel,
    maturityIndex,
    intentDistribution,
    adsTargetingHints,
    structuredSignals,
    inputSummary,
    engineVersion: AUDIENCE_ENGINE_VERSION,
    executionTimeMs,
    snapshotId: inserted.id,
    freshnessMetadata: miFreshnessMetadata,
    productDna: productDna || null,
    dataReliability,
    confidenceScore: dataReliability.overallReliability,
    audienceSophistication,
    buyerPsychologyProfile,
  };
}

export async function getLatestAudienceSnapshot(accountId: string, campaignId: string, runId?: string | null) {
  const baseFilters = [
    eq(audienceSnapshots.accountId, accountId),
    eq(audienceSnapshots.campaignId, campaignId),
  ];
  if (runId) baseFilters.push(eq(audienceSnapshots.jobId, runId));
  const query = db.select().from(audienceSnapshots).where(and(...baseFilters));
  const [snapshot] = runId
    ? await query.limit(1)
    : await query.orderBy(desc(audienceSnapshots.createdAt)).limit(1);

  if (!snapshot) return null;

  let freshnessMetadata = null;
  if (snapshot.miSnapshotId) {
    const [miSnap] = await db.select().from(miSnapshots)
      .where(and(eq(miSnapshots.id, snapshot.miSnapshotId), eq(miSnapshots.accountId, accountId)))
      .limit(1);
    if (miSnap) {
      const { buildFreshnessMetadata } = await import("../shared/snapshot-trust");
      freshnessMetadata = buildFreshnessMetadata(miSnap);
    }
  }

  return {
    ...snapshot,
    languageSignals: JSON.parse(snapshot.languageSignals || "{}"),
    painMap: JSON.parse(snapshot.audiencePains || "[]"),
    desireMap: JSON.parse(snapshot.desireMap || "[]"),
    objectionMap: JSON.parse(snapshot.objectionMap || "[]"),
    transformationMap: JSON.parse(snapshot.transformationMap || "[]"),
    emotionalDrivers: JSON.parse(snapshot.emotionalDrivers || "[]"),
    audienceSegments: JSON.parse(snapshot.audienceSegments || "[]"),
    segmentDensity: JSON.parse(snapshot.segmentDensity || "[]"),
    awarenessLevel: JSON.parse(snapshot.awarenessLevel || "{}"),
    maturityIndex: JSON.parse(snapshot.maturityIndex || "{}"),
    intentDistribution: JSON.parse(snapshot.audienceIntentDistribution || "{}"),
    adsTargetingHints: JSON.parse(snapshot.adsTargetingHints || "[]"),
    structuredSignals: JSON.parse(snapshot.structuredSignals || '{"pain_clusters":[],"desire_clusters":[],"pattern_clusters":[],"root_causes":[],"psychological_drivers":[]}'),
    inputSummary: JSON.parse(snapshot.inputSummary || "{}"),
    freshnessMetadata,
  };
}

export {
  detectMarketScope,
  getMarketScopeMetadata,
  filterClustersByMarket,
  applyObjectionContextRules,
  applyEvidenceIntegrityFilter,
  computeSegmentSimilarity,
  canonicalizeSegments,
  computeSegmentDensity,
  deriveIntentTemperature,
};
